
�

CallIntegrationSnapshotTestcom.dacaller.app2testNativeNotificationStatesActionsAndDirectReturn2�ܛ�����:�ܛ���ӱ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testNativeNotificationStatesActionsAndDirectReturn.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIntegrationSnapshotTestcom.dacaller.app>testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll2�ܛ��ޅ�:�ݛ����o"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
!CallIslandExternalIntegrationTestcom.dacaller.app5testActualTelecomExternalIslandOnLauncherAndOtherApps2�ݛ����q:�ݛ������
�junit.framework.AssertionFailedError: Native SystemUI answer did not activate actual Telecom call
at com.dacaller.app.CallIslandExternalIntegrationTest.await(CallIslandExternalIntegrationTest.java:208)
at com.dacaller.app.CallIslandExternalIntegrationTest.answerNativeIncoming(CallIslandExternalIntegrationTest.java:425)
at com.dacaller.app.CallIslandExternalIntegrationTest.scenario(CallIslandExternalIntegrationTest.java:635)
at com.dacaller.app.CallIslandExternalIntegrationTest.testActualTelecomExternalIslandOnLauncherAndOtherApps(CallIslandExternalIntegrationTest.java:582)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
$junit.framework.AssertionFailedError�junit.framework.AssertionFailedError: Native SystemUI answer did not activate actual Telecom call
at com.dacaller.app.CallIslandExternalIntegrationTest.await(CallIslandExternalIntegrationTest.java:208)
at com.dacaller.app.CallIslandExternalIntegrationTest.answerNativeIncoming(CallIslandExternalIntegrationTest.java:425)
at com.dacaller.app.CallIslandExternalIntegrationTest.scenario(CallIslandExternalIntegrationTest.java:635)
at com.dacaller.app.CallIslandExternalIntegrationTest.testActualTelecomExternalIslandOnLauncherAndOtherApps(CallIslandExternalIntegrationTest.java:582)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandExternalIntegrationTest-testActualTelecomExternalIslandOnLauncherAndOtherApps.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
|
CallIslandSnapshotTestcom.dacaller.app4testAllStylesLanguagesThemesAndCallStatesAtLargeFont2�ݛ����:�ݛ���ά"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testAllStylesLanguagesThemesAndCallStatesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCommandsConfirmationPauseReturnRecreationAndContentRestore2�ݛ�����:�ݛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCommandsConfirmationPauseReturnRecreationAndContentRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont2�ݛ��ɧ�:�ݛ��ꀇ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallLayoutSnapshotTestcom.dacaller.app8testAudioSelectionAndMuteRemainSynchronizedInEveryDesign2�ݛ�����:�ݛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testAudioSelectionAndMuteRemainSynchronizedInEveryDesign.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
w
CallLayoutSnapshotTestcom.dacaller.app0testFiveDesignsBothThemesFourPanelsAndLargeFonts2�ݛ���ޖ:�ޛ����0"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testFiveDesignsBothThemesFourPanelsAndLargeFonts.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
s
CallLayoutSnapshotTestcom.dacaller.app-testLongCallerNamesInBothLanguagesAtLargeFont2�ޛ���4:�ޛ��ʺ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testLongCallerNamesInBothLanguagesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallLayoutSnapshotTestcom.dacaller.app:testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout2�ޛ����:�ޛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
o
CallLayoutSnapshotTestcom.dacaller.app(testSequentialPanelsCloseAndNeverOverlap2�ޛ����:�ޛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testSequentialPanelsCloseAndNeverOverlap.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.appBtestContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder2�ޛ�����:�ޛ����a"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
p
ContactScrollDispatchTestcom.dacaller.app&testNewTouchCancelsQueuedReturnRestore2�ޛ����b:�ޛ���צ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testNewTouchCancelsQueuedReturnRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.app9testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor2�ޛ���˨:�ޛ���"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
z
ContactScrollDispatchTestcom.dacaller.app0testSearchFilterSurvivesDetailReturnWithoutReset2�ޛ����:�ޛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testSearchFilterSurvivesDetailReturnWithoutReset.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
z
ListDialDispatchTestcom.dacaller.app4testConfiguredHorizontalSwipeCallsCorrectContactOnce2�ޛ�����:�ޛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testConfiguredHorizontalSwipeCallsCorrectContactOnce.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�

ListDialDispatchTestcom.dacaller.app9testContactRowAndStarHaveIndependentActionsWithoutCalling2�ޛ�����:�ޛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactRowAndStarHaveIndependentActionsWithoutCalling.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ListDialDispatchTestcom.dacaller.app;testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump2�ޛ����:�ޛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
y
ListDialDispatchTestcom.dacaller.app4testRecentDialExactNumberAndIndependentDetailsRegion2�ޛ����:�ޛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testRecentDialExactNumberAndIndependentDetailsRegion.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
r
ListDialDispatchTestcom.dacaller.app-testVerticalFlickStartingAtCallIconNeverCalls2�ޛ��褚:�ޛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testVerticalFlickStartingAtCallIconNeverCalls.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app:testAllAvatarShapesClipActualContactPhotoAndWidgetInitials2�ޛ����:�ޛ����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testAllAvatarShapesClipActualContactPhotoAndWidgetInitials.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testArchiveResolvesRealProviderNamePhotoAndSearchesNames2�ޛ���ջ:�ޛ��ХL"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testArchiveResolvesRealProviderNamePhotoAndSearchesNames.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appJtestContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes2�ޛ��ٟM:�ߛ���P"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appFtestDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences2�ߛ����R:�ߛ��Ł�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appAtestEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves2�ߛ��Ӹ�:�ߛ���Æ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appNtestHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse2�ߛ��ꀇ:�ߛ����k"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes2�ߛ����m:�ߛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
SettingsInteractionTestcom.dacaller.appHtestLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol2�ߛ�����:�ߛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.SettingsInteractionTest-testLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
k
WidgetSnapshotTestcom.dacaller.app'testNarrowFavoritesFitAtLargeSystemFont2�ߛ�����:�ߛ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testNarrowFavoritesFitAtLargeSystemFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
r
WidgetSnapshotTestcom.dacaller.app.testRealHostAdditionResizeThemeEmptyAndRemoval2�ߛ�����:�ߛ���޾"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testRealHostAdditionResizeThemeEmptyAndRemoval.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/testlog/test-results.log 2
text/plain