
$�

CallIntegrationSnapshotTestcom.dacaller.app2testNativeNotificationStatesActionsAndDirectReturn2��������:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testNativeNotificationStatesActionsAndDirectReturn.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIntegrationSnapshotTestcom.dacaller.app>testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll2�����Ӹ�:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
!CallIslandExternalIntegrationTestcom.dacaller.app5testActualTelecomExternalIslandOnLauncherAndOtherApps2������ז:Ʃ������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandExternalIntegrationTest-testActualTelecomExternalIslandOnLauncherAndOtherApps.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
|
CallIslandSnapshotTestcom.dacaller.app4testAllStylesLanguagesThemesAndCallStatesAtLargeFont2Ʃ������:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testAllStylesLanguagesThemesAndCallStatesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCommandsConfirmationPauseReturnRecreationAndContentRestore2�����ɐ�:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCommandsConfirmationPauseReturnRecreationAndContentRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont2������̸:�����Ҋ�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�

CallLayoutSnapshotTestcom.dacaller.app8testAudioSelectionAndMuteRemainSynchronizedInEveryDesign2�������:�������O"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testAudioSelectionAndMuteRemainSynchronizedInEveryDesign.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
w
CallLayoutSnapshotTestcom.dacaller.app0testFiveDesignsBothThemesFourPanelsAndLargeFonts2�������P:ת������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testFiveDesignsBothThemesFourPanelsAndLargeFonts.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
u
CallLayoutSnapshotTestcom.dacaller.app-testLongCallerNamesInBothLanguagesAtLargeFont2ת������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testLongCallerNamesInBothLanguagesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallLayoutSnapshotTestcom.dacaller.app:testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
p
CallLayoutSnapshotTestcom.dacaller.app(testSequentialPanelsCloseAndNeverOverlap2�������:�����ޅ�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testSequentialPanelsCloseAndNeverOverlap.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app>testBundledBusinessDirectoryNativeIsolationSearchAndProvenance2��������:���������
�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java:202)
at com.dacaller.app.CallbackBusinessIntegrationTest.tapView(CallbackBusinessIntegrationTest.java:292)
at com.dacaller.app.CallbackBusinessIntegrationTest.businessScenario(CallbackBusinessIntegrationTest.java:691)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessDirectoryNativeIsolationSearchAndProvenance(CallbackBusinessIntegrationTest.java:543)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java:202)
at com.dacaller.app.CallbackBusinessIntegrationTest.tapView(CallbackBusinessIntegrationTest.java:292)
at com.dacaller.app.CallbackBusinessIntegrationTest.businessScenario(CallbackBusinessIntegrationTest.java:691)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessDirectoryNativeIsolationSearchAndProvenance(CallbackBusinessIntegrationTest.java:543)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testBundledBusinessDirectoryNativeIsolationSearchAndProvenance.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app:testBundledBusinessManualNativeCallUsesExactSourceIdentity2������ˏ:���������
�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java:202)
at com.dacaller.app.CallbackBusinessIntegrationTest.tapView(CallbackBusinessIntegrationTest.java:292)
at com.dacaller.app.CallbackBusinessIntegrationTest.businessManualDialScenario(CallbackBusinessIntegrationTest.java:628)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessManualNativeCallUsesExactSourceIdentity(CallbackBusinessIntegrationTest.java:546)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java�junit.framework.AssertionFailedError
at com.dacaller.app.CallbackBusinessIntegrationTest.tapPoint(CallbackBusinessIntegrationTest.java:202)
at com.dacaller.app.CallbackBusinessIntegrationTest.tapView(CallbackBusinessIntegrationTest.java:292)
at com.dacaller.app.CallbackBusinessIntegrationTest.businessManualDialScenario(CallbackBusinessIntegrationTest.java:628)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessManualNativeCallUsesExactSourceIdentity(CallbackBusinessIntegrationTest.java:546)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testBundledBusinessManualNativeCallUsesExactSourceIdentity.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app6testCallbackReminderFromActualTelecomAndPrivateOsAlarm2��������:�����Ք�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testCallbackReminderFromActualTelecomAndPrivateOsAlarm.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app=testUnknownActualRecentCallerOpensNewEditorWithoutDialOrWrite2�������:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testUnknownActualRecentCallerOpensNewEditorWithoutDialOrWrite.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.appBtestContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder2�������:�����ғ�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
q
ContactScrollDispatchTestcom.dacaller.app&testNewTouchCancelsQueuedReturnRestore2��������:������ǣ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testNewTouchCancelsQueuedReturnRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.app9testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor2��������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
{
ContactScrollDispatchTestcom.dacaller.app0testSearchFilterSurvivesDetailReturnWithoutReset2������׍:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testSearchFilterSurvivesDetailReturnWithoutReset.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
q
FollowupIntegrationTestcom.dacaller.app)testChangelogNativeSettingsHistoryAndBack2��������:«�����/"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.FollowupIntegrationTest-testChangelogNativeSettingsHistoryAndBack.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
FollowupIntegrationTestcom.dacaller.app<testMissedCallsFromActualTelecomAndNativeNotificationActions2«�����0:ѫ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.FollowupIntegrationTest-testMissedCallsFromActualTelecomAndNativeNotificationActions.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
y
ListDialDispatchTestcom.dacaller.app4testConfiguredHorizontalSwipeCallsCorrectContactOnce2ѫ���Ī":ѫ������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testConfiguredHorizontalSwipeCallsCorrectContactOnce.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�

ListDialDispatchTestcom.dacaller.app9testContactRowAndStarHaveIndependentActionsWithoutCalling2ѫ������:ҫ���Î�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactRowAndStarHaveIndependentActionsWithoutCalling.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ListDialDispatchTestcom.dacaller.app;testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump2ҫ���ٿ�:ӫ����'"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
y
ListDialDispatchTestcom.dacaller.app4testRecentDialExactNumberAndIndependentDetailsRegion2ӫ�����(:ӫ�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testRecentDialExactNumberAndIndependentDetailsRegion.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
r
ListDialDispatchTestcom.dacaller.app-testVerticalFlickStartingAtCallIconNeverCalls2ӫ������:ԫ����3"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testVerticalFlickStartingAtCallIconNeverCalls.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app:testAllAvatarShapesClipActualContactPhotoAndWidgetInitials2ԫ�����3:٫������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testAllAvatarShapesClipActualContactPhotoAndWidgetInitials.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testArchiveResolvesRealProviderNamePhotoAndSearchesNames2٫������:ܫ������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testArchiveResolvesRealProviderNamePhotoAndSearchesNames.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appJtestContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes2ܫ������:��������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appFtestDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences2��������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appAtestEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves2�������:�������
"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appNtestHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse2�������:������Ʌ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes2������Æ:������ĸ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
SettingsInteractionTestcom.dacaller.appHtestLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol2�����߸�:�������C"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.SettingsInteractionTest-testLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
j
WidgetSnapshotTestcom.dacaller.app'testNarrowFavoritesFitAtLargeSystemFont2�������D:������å"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testNarrowFavoritesFitAtLargeSystemFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
q
WidgetSnapshotTestcom.dacaller.app.testRealHostAdditionResizeThemeEmptyAndRemoval2��������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testRealHostAdditionResizeThemeEmptyAndRemoval.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/testlog/test-results.log 2
text/plain