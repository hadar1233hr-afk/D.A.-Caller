
"�

CallIntegrationSnapshotTestcom.dacaller.app2testNativeNotificationStatesActionsAndDirectReturn2�����݌:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testNativeNotificationStatesActionsAndDirectReturn.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIntegrationSnapshotTestcom.dacaller.app>testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIntegrationSnapshotTest-testSystemBackReturnsToLastContactQueryAnchorAndSettingsScroll.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
!CallIslandExternalIntegrationTestcom.dacaller.app5testActualTelecomExternalIslandOnLauncherAndOtherApps2�������:�����"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandExternalIntegrationTest-testActualTelecomExternalIslandOnLauncherAndOtherApps.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
|
CallIslandSnapshotTestcom.dacaller.app4testAllStylesLanguagesThemesAndCallStatesAtLargeFont2������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testAllStylesLanguagesThemesAndCallStatesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCommandsConfirmationPauseReturnRecreationAndContentRestore2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCommandsConfirmationPauseReturnRecreationAndContentRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallIslandSnapshotTestcom.dacaller.app>testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallIslandSnapshotTest-testCustomizationPreviewBothThemesAndBottomControlsAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�

CallLayoutSnapshotTestcom.dacaller.app8testAudioSelectionAndMuteRemainSynchronizedInEveryDesign2�������:������H"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testAudioSelectionAndMuteRemainSynchronizedInEveryDesign.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
w
CallLayoutSnapshotTestcom.dacaller.app0testFiveDesignsBothThemesFourPanelsAndLargeFonts2������H:�����ۺ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testFiveDesignsBothThemesFourPanelsAndLargeFonts.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
u
CallLayoutSnapshotTestcom.dacaller.app-testLongCallerNamesInBothLanguagesAtLargeFont2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testLongCallerNamesInBothLanguagesAtLargeFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallLayoutSnapshotTestcom.dacaller.app:testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout2�����˘:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testNoBluetoothRouteWithoutConnectedDeviceAndEnglishLayout.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
p
CallLayoutSnapshotTestcom.dacaller.app(testSequentialPanelsCloseAndNeverOverlap2�����צ:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallLayoutSnapshotTest-testSequentialPanelsCloseAndNeverOverlap.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app>testBundledBusinessDirectoryNativeIsolationSearchAndProvenance2�������:������
�junit.framework.AssertionFailedError: BLOCKED: no verified licensed business asset is bundled expected:<AVAILABLE> but was:<MISSING>
at com.dacaller.app.CallbackBusinessIntegrationTest.businessScenario(CallbackBusinessIntegrationTest.java:429)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessDirectoryNativeIsolationSearchAndProvenance(CallbackBusinessIntegrationTest.java:406)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
$junit.framework.AssertionFailedError�junit.framework.AssertionFailedError: BLOCKED: no verified licensed business asset is bundled expected:<AVAILABLE> but was:<MISSING>
at com.dacaller.app.CallbackBusinessIntegrationTest.businessScenario(CallbackBusinessIntegrationTest.java:429)
at com.dacaller.app.CallbackBusinessIntegrationTest.testBundledBusinessDirectoryNativeIsolationSearchAndProvenance(CallbackBusinessIntegrationTest.java:406)
at android.test.InstrumentationTestCase.runMethod(InstrumentationTestCase.java:220)
at android.test.InstrumentationTestCase.runTest(InstrumentationTestCase.java:205)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:195)
at android.test.AndroidTestRunner.runTest(AndroidTestRunner.java:181)
at android.test.InstrumentationTestRunner.onStart(InstrumentationTestRunner.java:563)
at android.app.Instrumentation$InstrumentationThread.run(Instrumentation.java:2361)
"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testBundledBusinessDirectoryNativeIsolationSearchAndProvenance.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
CallbackBusinessIntegrationTestcom.dacaller.app6testCallbackReminderFromActualTelecomAndPrivateOsAlarm2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.CallbackBusinessIntegrationTest-testCallbackReminderFromActualTelecomAndPrivateOsAlarm.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.appBtestContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testContactReturnPreservesStableIdentityOffsetAndQueryAfterReorder.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
q
ContactScrollDispatchTestcom.dacaller.app&testNewTouchCancelsQueuedReturnRestore2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testNewTouchCancelsQueuedReturnRestore.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ContactScrollDispatchTestcom.dacaller.app9testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor2����:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testRepeatedRebuildBeforeSelectionLayoutDoesNotLoseAnchor.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
{
ContactScrollDispatchTestcom.dacaller.app0testSearchFilterSurvivesDetailReturnWithoutReset2�������:����־�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ContactScrollDispatchTest-testSearchFilterSurvivesDetailReturnWithoutReset.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
r
FollowupIntegrationTestcom.dacaller.app)testChangelogNativeSettingsHistoryAndBack2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.FollowupIntegrationTest-testChangelogNativeSettingsHistoryAndBack.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
FollowupIntegrationTestcom.dacaller.app<testMissedCallsFromActualTelecomAndNativeNotificationActions2�������:������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.FollowupIntegrationTest-testMissedCallsFromActualTelecomAndNativeNotificationActions.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
y
ListDialDispatchTestcom.dacaller.app4testConfiguredHorizontalSwipeCallsCorrectContactOnce2�������:������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testConfiguredHorizontalSwipeCallsCorrectContactOnce.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
~
ListDialDispatchTestcom.dacaller.app9testContactRowAndStarHaveIndependentActionsWithoutCalling2������:����ᔧ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactRowAndStarHaveIndependentActionsWithoutCalling.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
ListDialDispatchTestcom.dacaller.app;testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump2�����˨:������`"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testContactsTopMiddleEndDialExactDisplayedNumberWithoutJump.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
y
ListDialDispatchTestcom.dacaller.app4testRecentDialExactNumberAndIndependentDetailsRegion2������a:�����τ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testRecentDialExactNumberAndIndependentDetailsRegion.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
s
ListDialDispatchTestcom.dacaller.app-testVerticalFlickStartingAtCallIconNeverCalls2����ᆆ:����̖�"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.ListDialDispatchTest-testVerticalFlickStartingAtCallIconNeverCalls.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app:testAllAvatarShapesClipActualContactPhotoAndWidgetInitials2����Ր�:������("�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testAllAvatarShapesClipActualContactPhotoAndWidgetInitials.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testArchiveResolvesRealProviderNamePhotoAndSearchesNames2������+:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testArchiveResolvesRealProviderNamePhotoAndSearchesNames.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appJtestContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes2����ҡ�:������K"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testContactsAndRecentsCompactPresentationInBothLanguagesThemesAndFontSizes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appFtestDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences2����ٟM:�����͙"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testDocumentBackupRestoreRequiresConfirmationAndCancelKeepsPreferences.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appAtestEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves2�������:
�����="�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testEveryRealLauncherAliasRemainsUniqueAndDialIntentStillResolves.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.appNtestHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse2������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testHorizontalFavoritesReachAllContactsWithoutDialingAndRememberSharedCollapse.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
PersonalizationSnapshotTestcom.dacaller.app8testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes2�������:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.PersonalizationSnapshotTest-testSettingsIconAndAvatarChoosersAtLargeFontInBothThemes.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
�
SettingsInteractionTestcom.dacaller.appHtestLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol2������:�����Ռ"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.SettingsInteractionTest-testLastSettingsCategoryStaysInteractiveAndCallsCategoryHasNoPhoneSymbol.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
j
WidgetSnapshotTestcom.dacaller.app'testNarrowFavoritesFitAtLargeSystemFont2�����ύ:������e"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testNarrowFavoritesFitAtLargeSystemFont.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo�
q
WidgetSnapshotTestcom.dacaller.app.testRealHostAdditionResizeThemeEmptyAndRemoval2������f:�������"�

logcatandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/logcat-com.dacaller.app.WidgetSnapshotTest-testRealHostAdditionResizeThemeEmptyAndRemoval.txt"�

device-infoandroid�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/device-info.pb"�

device-info.meminfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/meminfo"�

device-info.cpuinfoandroid|
z/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/D.A.-Caller/D.A.-Caller/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 13/testlog/test-results.log 2
text/plain