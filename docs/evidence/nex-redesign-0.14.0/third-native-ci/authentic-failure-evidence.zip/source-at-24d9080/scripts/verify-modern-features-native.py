#!/usr/bin/env python3
"""Additive0.14 native gate: original245 frames AND27 real compositor frames.

This gate does not authorize publication/signing or relabel preview fixtures as
Telecom proof. It requires all original gate reports, actual current-source
instrumentation JUnit, source-bound screenshot hashes and independent saved
pixel verification of the transparency proof. No diagnostics are filtered out.
"""
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
import zlib

PRESENTATION = {f"modern-{part}-{suffix}.png" for part in (
    "recents-inline", "bottom-dialpad", "icons-all-nine", "wine-controls")
    for suffix in ("light-en", "dark-he")}
WIDGET = {"modern-nex-widget-light-he.png", "modern-nex-widget-amoled-en.png"}
PRESENTATION |= WIDGET
BACKUP = {f"modern-{part}.png" for part in (
    "backup-options-off", "backup-options-on", "archive-restore-off",
    "archive-restore-on", "archive-merged")}
ISLAND = {f"modern-island-{part}.png" for part in (
    "dragged", "hide-home", "restore-home", "status-external", "status-inapp",
    "below-inapp", "composition-background", "opacity-0", "opacity-35",
    "opacity-100", "new-call-shown")}
NEX_ISLAND = "modern-nex-island-active-he.png"
ISLAND.add(NEX_ISLAND)
REQUIRED = PRESENTATION | BACKUP | ISLAND
PROOFS = {"modern-presentation-native.json": PRESENTATION,
          "modern-backup-native.json": BACKUP,
          "modern-island-native.json": ISLAND}
LEGACY = {"matrix-verification.json": 122,
          "personalization-verification.json": 53,
          "call-integration-verification.json": 8,
          "island-verification.json": 36,
          "external-island-verification.json": 8,
          "followup-verification.json": 6,
          "callback-business-verification.json": 12}


def require(value, message):
    if not value:
        raise AssertionError(message)


def integer(value, expected=None):
    return type(value) is int and (expected is None or value == expected)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def one(root, name):
    files = [p for p in root.rglob(name) if p.is_file()]
    require(len(files) == 1, f"Missing/duplicate {name}: {len(files)}")
    value = json.loads(files[0].read_text(), object_pairs_hook=strict_object,
                       parse_constant=lambda value: require(False, "Invalid JSON number: " + value))
    require(type(value) is dict, "Evidence must be a JSON object: " + name)
    return value


def flags(value, names):
    for name in names:
        require(value.get(name) is True, f"Missing native assertion: {name}")


def large_font(value):
    return type(value) in (int, float) and abs(value - 1.3) <= 0.000001


def rectangle(value):
    match = re.fullmatch(r"\[([0-9]+),([0-9]+)\]\[([0-9]+),([0-9]+)\]", str(value))
    require(match is not None, f"Missing native rectangle: {value}")
    left, top, right, bottom = map(int, match.groups())
    require(0 <= left < right <= 480 and 0 <= top < bottom <= 854,
            f"Native rectangle outside480x854: {value}")
    return left, top, right, bottom


def png(content, name, decode=False):
    """Validate complete saved PNG, optionally unfilter actual RGB sample rows."""
    require(len(content) > 1000 and content[:8] == b"\x89PNG\r\n\x1a\n", f"Invalid native PNG: {name}")
    offset, payload, header, ended = 8, bytearray(), None, False
    while offset < len(content):
        require(offset + 12 <= len(content), f"Truncated PNG chunk: {name}")
        length = struct.unpack(">I", content[offset:offset + 4])[0]
        kind = content[offset + 4:offset + 8]
        end = offset + 12 + length
        require(end <= len(content), f"Truncated PNG payload: {name}")
        chunk = content[offset + 8:offset + 8 + length]
        crc = struct.unpack(">I", content[offset + 8 + length:end])[0]
        require(zlib.crc32(kind + chunk) & 0xffffffff == crc, f"PNG CRC mismatch: {name}")
        if kind == b"IHDR":
            require(header is None and offset == 8 and length == 13, f"Invalid PNG header: {name}")
            header = struct.unpack(">IIBBBBB", chunk)
        elif kind == b"IDAT":
            require(header is not None and not ended, f"Invalid PNG data order: {name}")
            payload.extend(chunk)
        elif kind == b"tRNS":
            require(False, f"Native compositor PNG cannot use color-key transparency: {name}")
        elif kind == b"IEND":
            require(length == 0 and end == len(content), f"Invalid PNG ending: {name}")
            ended = True
        offset = end
    require(header is not None and ended and payload, f"Incomplete native PNG: {name}")
    width, height, depth, color, compression, filtering, interlace = header
    require((width, height) == (480, 854) and depth == 8 and color in (2, 6)
            and (compression, filtering, interlace) == (0, 0, 0), f"Wrong native PNG encoding: {name}")
    channels = 3 if color == 2 else 4
    stride = width * channels
    expected = height * (stride + 1)
    decoder = zlib.decompressobj()
    data = decoder.decompress(bytes(payload), expected + 1)
    require(len(data) == expected and decoder.eof and not decoder.unused_data
            and not decoder.unconsumed_tail, f"Invalid native PNG compressed stream: {name}")
    if not decode:
        require(all(data[y * (stride + 1)] <= 4 for y in range(height)), f"Invalid PNG filter: {name}")
        return None
    rows, previous, position = [], bytearray(stride), 0
    for _ in range(height):
        method = data[position]
        require(method <= 4, f"Invalid PNG row filter: {name}")
        row = bytearray(data[position + 1:position + 1 + stride])
        for index in range(stride):
            left = row[index - channels] if index >= channels else 0
            above = previous[index]
            upper_left = previous[index - channels] if index >= channels else 0
            if method == 1:
                predictor = left
            elif method == 2:
                predictor = above
            elif method == 3:
                predictor = (left + above) // 2
            elif method == 4:
                estimate = left + above - upper_left
                distance = (abs(estimate - left), abs(estimate - above), abs(estimate - upper_left))
                predictor = left if distance[0] <= min(distance[1:]) else above if distance[1] <= distance[2] else upper_left
            else:
                predictor = 0
            row[index] = (row[index] + predictor) & 255
        rows.append(row)
        previous, position = row, position + stride + 1
    return rows, channels


def junit(root, sources):
    expected = set()
    for source in sources.glob("*.java"):
        text = source.read_text()
        methods = re.findall(r"public\s+void\s+(test\w+)\s*\(\s*\)", text)
        for method in methods:
            expected.add(("com.dacaller.app." + source.stem, method))
    require(len(expected) == 40, "Current native source must retain36original+1inline+3modern cases")
    require(sum(owner.endswith(".ModernFeaturesIntegrationTest") for owner, _ in expected) == 3,
            "Missing additive native methods")
    files = sorted(root.rglob("*.xml"))
    require(bool(files), "Authentic native JUnit is missing")
    actual, hashes = set(), {}
    for path in files:
        data = path.read_bytes()
        document = ET.fromstring(data)
        require(document.tag in {"testsuite", "testsuites"}, "Unexpected native JUnit root")
        for tag in ("failure", "error", "skipped"):
            require(not list(document.iter(tag)), "Native JUnit contains " + tag)
        for suite in document.iter("testsuite"):
            for key in ("failures", "errors", "skipped"):
                if key in suite.attrib:
                    require(suite.attrib[key] == "0", "Nonzero native JUnit " + key)
            cases = list(suite.iter("testcase"))
            if "tests" in suite.attrib:
                require(suite.attrib["tests"].isdigit() and int(suite.attrib["tests"]) == len(cases), "Native JUnit counter mismatch")
        if document.tag == "testsuites" and "tests" in document.attrib:
            count = document.attrib["tests"]
            require(count.isdigit() and int(count) == len(list(document.iter("testcase"))), "Native JUnit aggregate counter mismatch")
        for key in ("failures", "errors", "skipped"):
            if key in document.attrib:
                require(document.attrib[key] == "0", "Nonzero native JUnit aggregate " + key)
        for case in document.iter("testcase"):
            identity = (case.get("classname"), case.get("name"))
            require(identity not in actual, "Duplicate native JUnit method")
            actual.add(identity)
        hashes[path.relative_to(root).as_posix()] = hashlib.sha256(data).hexdigest()
    require(actual == expected, f"Native current-source methods differ: missing={sorted(expected - actual)}, extra={sorted(actual - expected)}")
    return {"tests": len(actual), "failures": 0, "errors": 0, "skipped": 0, "files_sha256": hashes}


def presentation(proof, images):
    flags(proof, ("no_floating_dialpad", "all_inline_actions_retained", "back_collapses_without_dial"))
    observations = proof.get("observations", [])
    require([(o.get("theme"), o.get("language")) for o in observations] == [("light", "en"), ("dark", "he")], "Both native theme/language cases required")
    for value in observations:
        require(large_font(value.get("font_scale")), "Actual large-font configuration missing")
        require(integer(value.get("inline_expansion_dial_requests"), 0) and integer(value.get("icon_choices"), 9)
                and value.get("selected_last_icon") == "signal", "Inline no-dial/ninth picker entry failed")
        left, top, right, bottom = rectangle(value.get("settings_bounds"))
        require(left < 30 and right - left >= 72 and bottom - top >= 72, "Settings must be top-left and48dp")
        left, top, right, bottom = rectangle(value.get("dialpad_nav_bounds"))
        require(top > 427 and bottom - top >= 72, "Bottom dialpad target must be accessible48dp")
        flags(value, ("switch_native_pointer_drag", "switch_accessibility_checkable"))
        require(type(value.get("switch_before")) is bool and type(value.get("switch_after")) is bool
                and value["switch_before"] != value["switch_after"], "Native wine Switch did not toggle")
        left, top, right, bottom = rectangle(value.get("switch_bounds"))
        require(right - left >= 72 and bottom - top >= 72, "Native Switch is smaller than48dp")
    widget_configuration(proof.get("widget_configuration"), images)


def backup(proof):
    flags(proof, ("independent_export_and_restore_opt_ins", "insert_only_conflicts_preserved", "settings_only_legacy_compatible"))
    require("test ContentProvider" in proof.get("document_flow", ""), "Do not claim human DocumentsUI interaction")
    observations = proof.get("observations", [])
    require(len(observations) == 1, "One complete same-file backup scenario required")
    value = observations[0]
    for key, expected in {"legacy_version": 1, "legacy_contains_archive": False, "bundle_version": 2,
                          "export_archive_default": False, "restore_archive_default": False,
                          "archive_policy_at_export": "off", "opt_out_added": 0, "opt_in_added": 1,
                          "same_identity_conflict_retained_seconds": 999,
                          "pending_recovery_after_success": False, "raw_archive_uploaded": False}.items():
        require(type(value.get(key)) is type(expected) and value[key] == expected, "Wrong backup result: " + key)
    before = value.get("preexisting_rows_preserved")
    require(type(before) is int and before >= 0 and integer(value.get("stored_rows_before"), before + 2) and integer(value.get("stored_rows_exported"), before + 2),
            "All stored rows including OFF-policy records must be exported and retained")


def argb(decoded, x, y):
    rows, channels = decoded
    pixel = rows[y][x * channels:(x + 1) * channels]
    require(channels == 3 or pixel[3] == 255, "Real compositor samples must be opaque")
    return (0xff << 24) | (pixel[0] << 16) | (pixel[1] << 8) | pixel[2]


def finite_number(value):
    return type(value) in (int, float) and -sys.float_info.max <= value <= sys.float_info.max and math.isfinite(value)


def contained(outer, inner):
    return outer[0] <= inner[0] < inner[2] <= outer[2] and outer[1] <= inner[1] < inner[3] <= outer[3]


def native_geometry(value, expected):
    require(type(value) is dict, "Actual native caller/capsule geometry missing")
    bounds = rectangle(value.get("bounds"))
    require(bounds == expected and rectangle(value.get("native_ax_bounds")) == expected,
            "Actual native AX bounds must equal laid-out caller/capsule bounds")
    require(integer(value.get("window_id")) and value["window_id"] >= 0
            and integer(value.get("stable_samples")) and value["stable_samples"] >= 2,
            "Actual native geometry needs a window and two stable samples")
    flags(value, ("view_window_focus", "native_window_focus"))
    return value["window_id"]


RESUMED_ACTIVITY = re.compile(
    r"[ \t]*(?:mResumedActivity|topResumedActivity)[ \t]*[:=][ \t]*ActivityRecord\{"
    r"[0-9a-fA-F]+[ \t]+u[0-9]+[ \t]+([^\s}]+)(?:\}[ \t]+t[0-9]+\}|[ \t]+t[0-9]+\})[ \t]*")


def resumed_activity_record(record, component):
    """Exact compact/qualified component in an API33 or historical resumed row."""
    if type(record) is not str:
        return False
    match = RESUMED_ACTIVITY.fullmatch(record)
    if match is None:
        return False
    package, activity = component.split("/", 1)
    qualified = package + "/" + (package + activity if activity.startswith(".") else activity)
    return match.group(1) in (component, qualified)


def widget_configuration(proof, images):
    require(type(proof) is dict, "Actual WidgetConfigure configuration preview proof missing")
    require(proof.get("scope") == "Actual WidgetConfigure Activity; synthetic unbound ID configuration preview"
            and proof.get("launcher_host_binding") == "NOT_TESTED", "Synthetic widget preview cannot claim launcher-host binding")
    flags(proof, ("preferences_restored",))
    observations = proof.get("observations", [])
    require(type(observations) is list and [(v.get("theme"), v.get("language")) for v in observations]
            == [("light", "he"), ("amoled", "en")], "Both actual WidgetConfigure theme/language previews required")
    for value in observations:
        amoled = value["theme"] == "amoled"
        frame = "modern-nex-widget-" + ("amoled-en" if amoled else "light-he") + ".png"
        require(value.get("frame") == frame and frame in images, "Widget preview must bind its exact compositor image")
        require(value.get("activity") == "com.dacaller.app.WidgetConfigure" and value.get("amoled") is amoled
                and value.get("layout_direction") == ("LTR" if amoled else "RTL")
                and large_font(value.get("font_scale")), "Widget preview must use the actual localized production Activity")
        require(integer(value.get("widget_id"), 2147483000) and integer(value.get("intent_widget_id"), 2147483000)
                and value.get("widget_provider_info") == "null", "Widget preview requires explicit synthetic unbound nonINVALID ID")
        foreground = value.get("foreground", {})
        component = "com.dacaller.app/.WidgetConfigure"
        require(foreground.get("component") == component and resumed_activity_record(foreground.get("resumed_record"), component),
            "Actual WidgetConfigure resumed component is missing")
        flags(foreground, ("top_resumed", "native_application_window_visible"))
        require(integer(foreground.get("window_id")) and foreground["window_id"] >= 0, "Actual WidgetConfigure native window missing")
        geometry = {}
        for name in ("root", "heading", "search", "back"):
            record = value.get(name + "_geometry", {})
            bounds = rectangle(record.get("bounds"))
            require(native_geometry(record, bounds) == foreground["window_id"], "Widget views must share the actual focused window")
            geometry[name] = bounds
            if name != "root":
                require(contained(geometry["root"], bounds), "Widget content must remain inside its visible root")
        for name, minimum in (("back", 72), ("search", 81)):
            left, top, right, bottom = geometry[name]
            require(right - left >= 72 and bottom - top >= minimum, "Widget back/search targets must be48dp/54dp")
        bg, surface, ink, muted = ((0xff000000, 0xff0a0a0a, 0xfff9f1e8, 0xfff2e5dd) if amoled
                                   else (0xfff6f0e8, 0xfffffdfc, 0xff37291f, 0xff4c352a))
        for key, color in (("background_argb", bg), ("surface_argb", surface), ("heading_argb", ink),
                           ("search_argb", ink), ("hint_argb", muted), ("status_bar_argb", bg), ("navigation_bar_argb", bg)):
            require(integer(value.get(key)) and -(1 << 31) <= value[key] < (1 << 31)
                    and value[key] & 0xffffffff == color, "Widget NEX/AMOLED live color differs: " + key)
        heading, hint = value.get("heading", {}), value.get("search_hint", {})
        for record, text, size, weight in ((heading, "Choose a contact" if amoled else "בחר איש קשר", 22, 750),
                                           (hint, "Search name or number" if amoled else "חיפוש שם או מספר", 16, 600)):
            require(record.get("text") == text and finite_number(record.get("text_size_sp"))
                    and abs(record["text_size_sp"] - size) <= 0.01 and integer(record.get("font_weight"), weight)
                    and record.get("font_variation") == "'wght' " + str(weight), "Widget localized text/font differs")
        for key in ("layout_width_px", "content_width_px", "content_height_px"):
            require(integer(heading.get(key)) and heading[key] > 0, "Actual widget heading layout metrics missing")
        require(heading["layout_width_px"] == heading["content_width_px"] <= geometry["heading"][2] - geometry["heading"][0]
                and heading["content_height_px"] <= geometry["heading"][3] - geometry["heading"][1], "Widget heading layout exceeds visible text area")
        lines, covered, previous_bottom = heading.get("lines", []), 0, 0
        require(type(lines) is list and bool(lines), "Actual widget heading lines missing")
        for line in lines:
            require(integer(line.get("start_utf16"), covered) and integer(line.get("end_utf16")) and line["end_utf16"] > covered
                    and integer(line.get("ellipsis_count"), 0), "Widget heading is clipped/ellipsized")
            require(finite_number(line.get("left_px")) and finite_number(line.get("right_px"))
                    and -1 <= line["left_px"] < line["right_px"] <= heading["layout_width_px"] + 1
                    and integer(line.get("bottom_px")) and previous_bottom < line["bottom_px"] <= heading["content_height_px"],
                    "Widget heading actual Layout must fit its visible bounds")
            covered, previous_bottom = line["end_utf16"], line["bottom_px"]
        require(covered == len(heading["text"].encode("utf-16-le")) // 2, "Widget heading must show every character")
        for key in ("available_width_px", "baseline_px", "padding_top_px", "padding_bottom_px", "height_px"):
            require(integer(hint.get(key)) and hint[key] >= 0, "Actual widget search layout metrics missing")
        require(0 < hint["available_width_px"] <= geometry["search"][2] - geometry["search"][0]
                and hint["height_px"] == geometry["search"][3] - geometry["search"][1]
                and finite_number(hint.get("measured_width_px")) and 0 < hint["measured_width_px"] <= hint["available_width_px"]
                and finite_number(hint.get("font_top_px")) and hint["font_top_px"] < 0
                and finite_number(hint.get("font_bottom_px")) and hint["font_bottom_px"] > 0
                and hint["baseline_px"] + hint["font_top_px"] >= hint["padding_top_px"] - 1
                and hint["baseline_px"] + hint["font_bottom_px"] <= hint["height_px"] - hint["padding_bottom_px"] + 1,
                "Widget search hint must fit the actual text width and font baseline")
        samples = value.get("background_samples", [])
        require(type(samples) is list and len(samples) == 5, "Widget compositor background samples missing")
        decoded, points = png(images[frame].read_bytes(), frame, True), set()
        for sample in samples:
            x, y = sample.get("x"), sample.get("y")
            require(integer(x) and integer(y) and geometry["root"][0] < x < geometry["root"][0] + 24
                    and geometry["root"][1] < y < geometry["root"][1] + 12 and (x, y) not in points,
                    "Widget background samples must lie in its clear native root padding")
            require(integer(sample.get("argb")) and -(1 << 31) <= sample["argb"] < (1 << 31)
                    and sample["argb"] & 0xffffffff == argb(decoded, x, y) == bg, "Widget background differs from actual saved PNG")
            points.add((x, y))
        for key in ("selection_actions", "native_pointer_inputs", "provider_writes_requested", "provider_change_notifications"):
            require(integer(value.get(key), 0), "Widget preview must remain read-only without selection/input/provider changes: " + key)
        flags(value, ("preferences_unchanged", "telecom_call_unchanged", "finished"))


def signed_rectangle(value):
    match = re.fullmatch(r"\[(-?[0-9]+),(-?[0-9]+)\]\[(-?[0-9]+),(-?[0-9]+)\]", str(value))
    require(match is not None, "Missing native server/mapped rectangle")
    result = tuple(map(int, match.groups()))
    require(result[0] < result[2] and result[1] < result[3] and all(abs(v) <= 10000 for v in result),
            "Invalid native server/mapped rectangle")
    return result


def status_bar_protection(value, capsule, inset):
    """Bind protected lanes to the actual API33 SystemUI input window/matrix.

    This proves native window presence and geometry. Icon pixels still require
    review of the complete real compositor capture; no AX icon IDs are guessed.
    """
    require(type(value) is dict, "Actual native SystemUI status-bar protection missing")
    require(value.get("system_ui_package") == "com.android.systemui"
            and integer(value.get("system_ui_uid")) and value["system_ui_uid"] > 0,
            "Actual SystemUI package-manager UID missing")
    record = value.get("system_ui_package_record")
    match = re.fullmatch(r"package:com\.android\.systemui uid:(\d+)", record) if type(record) is str else None
    require(match is not None and int(match[1]) == value["system_ui_uid"],
            "Actual package-manager SystemUI record must match native UID")
    flags(value, ("window_has_input_token", "window_visible", "root_status_bars_visible",
                  "clock_lane_clear", "right_icon_lane_clear"))
    require(integer(value.get("root_status_inset"), inset)
            and integer(value.get("stable_samples")) and value["stable_samples"] >= 2,
            "Native status bar must match actual root inset in two stable dumps")
    window = value.get("native_window")
    require(type(window) is dict and integer(window.get("index")) and window["index"] >= 0
            and integer(window.get("id")) and window["id"] >= 0
            and integer(window.get("uid"), value["system_ui_uid"]), "Native StatusBar window owner differs from SystemUI")
    require(type(window.get("name")) is str and (window["name"] == "StatusBar" or window["name"].endswith(" StatusBar")),
            "Native SystemUI window must be actual StatusBar")
    config = window.get("input_config")
    known = {"NO_INPUT_CHANNEL", "NOT_VISIBLE", "NOT_FOCUSABLE", "NOT_TOUCHABLE", "PREVENT_SPLITTING",
             "DUPLICATE_TOUCH_TO_WALLPAPER", "IS_WALLPAPER", "PAUSE_DISPATCHING", "TRUSTED_OVERLAY",
             "WATCH_OUTSIDE_TOUCH", "SLIPPERY", "DISABLE_USER_ACTIVITY", "DROP_INPUT", "DROP_INPUT_IF_OBSCURED",
             "SPY", "INTERCEPTS_STYLUS"}
    require(type(config) is str, "Native StatusBar input configuration missing")
    entries = config.split(" | ")
    require(config == "0x0" or len(set(entries)) == len(entries) and set(entries) <= known,
            "Native StatusBar has unknown input configuration")
    require("NOT_VISIBLE" not in entries and "NO_INPUT_CHANNEL" not in entries and "TRUSTED_OVERLAY" in entries,
            "Native StatusBar window must be a visible trusted overlay with an input channel")
    raw = window.get("raw")
    pattern = (r"\s*(\d+): name='(.*)', id=(-?\d+), displayId=(-?\d+), inputConfig=(.*?), alpha=([0-9.]+), "
               r"frame=(\[-?\d+,-?\d+\]\[-?\d+,-?\d+\]), globalScale=([0-9.]+), applicationInfo\.name=(.*?), "
               r"applicationInfo\.token=(.*?), touchableRegion=(.*?), ownerPid=(-?\d+), ownerUid=(-?\d+), "
               r"dispatchingTimeout=(-?\d+)ms, hasToken=(true|false), touchOcclusionMode=(\S+)\s*")
    match = re.fullmatch(pattern, raw) if type(raw) is str else None
    require(match is not None, "Actual API33 StatusBar input-window raw record missing")
    require(int(match[1]) == window["index"] and match[2] == window["name"] and int(match[3]) == window["id"]
            and int(match[4]) == 0 and match[5] == config and match[7] == window.get("frame")
            and int(match[13]) == window["uid"] and match[15] == "true",
            "Reported StatusBar window differs from actual native raw record")
    alpha = float(match[6])
    require(math.isfinite(alpha) and 0 < alpha <= 1, "Actual native StatusBar alpha must be visible")
    frame = signed_rectangle(window.get("frame"))
    transform = value.get("display_transform")
    require(type(transform) is dict and type(transform.get("raw")) is str, "Actual native display transform missing")
    lines = [line.strip() for line in transform["raw"].strip().splitlines()]
    require(len(lines) == 6 and lines[0] == "Display: 0" and lines[1] == "logicalSize=480x854"
            and re.fullmatch(r"transform \(ROT_0\) \((?:IDENTITY|SCALE|TRANSLATE|SCALE TRANSLATE)\)", lines[2]),
            "Native StatusBar transform must use actual display0 fixed portrait geometry")
    matrix = []
    for line in lines[3:]:
        cells = line.split()
        require(len(cells) == 3 and all(re.fullmatch(r"-?\d+(?:\.\d+)?", cell) for cell in cells),
                "Malformed native StatusBar transform matrix")
        matrix.append([float(cell) for cell in cells])
    require(all(math.isfinite(cell) for row in matrix for cell in row)
            and matrix[0][1] == matrix[1][0] == matrix[2][0] == matrix[2][1] == 0 and matrix[2][2] == 1,
            "Native StatusBar transform cannot rotate, shear or use perspective")
    sx, sy, tx, ty = matrix[0][0], matrix[1][1], matrix[0][2], matrix[1][2]
    require(0.00005 < sx <= 16 and 0.00005 < sy <= 16 and abs(tx) <= 10000 and abs(ty) <= 10000,
            "Native StatusBar transform out of range")
    require(all(finite_number(transform.get(key)) and transform[key] == expected
                for key, expected in (("scale_x", sx), ("scale_y", sy), ("translate_x", tx), ("translate_y", ty))),
            "Reported StatusBar transform differs from actual native raw matrix")
    mapped = (sx * frame[0] + tx, sy * frame[1] + ty, sx * frame[2] + tx, sy * frame[3] + ty)
    require(abs(mapped[0]) <= 1 and abs(mapped[1]) <= 1 and abs(mapped[2] - 480) <= 1,
            "Actual native StatusBar must map to the full-width screen-top strip")
    strip = (max(0, math.floor(mapped[0])), max(0, math.floor(mapped[1])),
             min(480, math.ceil(mapped[2])), math.ceil(mapped[3]))
    require(signed_rectangle(value.get("mapped_status_bounds")) == strip
            and inset - 1 <= mapped[3] <= inset + 2 and inset - 1 <= strip[3] <= inset + 2,
            "Mapped native StatusBar strip must match actual inset and recorded transform")
    for key, expected in (("clock_lane_bounds", (0, 0, 90, strip[3])),
                          ("right_icon_lane_bounds", (390, 0, 480, strip[3]))):
        lane = signed_rectangle(value.get(key))
        require(lane == expected, "Protected native clock/right-icon lanes must retain60dp")
        require(not (capsule[0] < lane[2] and lane[0] < capsule[2] and capsule[1] < lane[3] and lane[1] < capsule[3]),
                "Actual capsule overlaps protected native clock/right-icon lane")
    require(value.get("proof_scope") == "Native SystemUI StatusBar window, root WindowInsets and protected geometric lanes; icon visual presence is reviewed in the real capture",
            "Native status protection scope must retain actual-capture icon review limitation")


def readable_status_surface(value):
    """Derive status placement from native Layout/Paint metrics, never its label."""
    require(type(value) is dict, "Readable status surface must be an object")
    require(integer(value.get("display_width"), 480) and integer(value.get("display_height"), 854)
            and integer(value.get("density_dpi"), 240) and large_font(value.get("font_scale")),
            "Readable status proof must retain fixed480x854/240dpi/font1.3")
    require(value.get("position_mode") == "status_area" and value.get("custom_position_set") is False,
            "Readable status proof must use actual status_area mode without a custom position")
    capsule = rectangle(value.get("bounds"))
    capsule_geometry, caller_geometry = value.get("capsule_geometry"), value.get("caller_geometry")
    capsule_window = native_geometry(capsule_geometry, capsule)
    require(type(caller_geometry) is dict, "Actual native caller geometry missing")
    caller = rectangle(caller_geometry.get("bounds"))
    require(contained(capsule, caller), "Actual caller bounds must fit completely inside capsule")
    require(native_geometry(caller_geometry, caller) == capsule_window,
            "Actual caller and capsule must belong to the same focused native window")
    require(integer(value.get("caller_line_count"), 1) and value.get("caller_ellipsize") == "END",
            "Actual caller Layout must remain one line with END ellipsization")
    full = value.get("caller_full_text")
    require(type(full) is str and bool(full) and not any(0xd800 <= ord(char) <= 0xdfff for char in full),
            "Actual caller identity must be nonempty Unicode text")
    require(integer(value.get("caller_code_points"), len(full)), "Caller full-text code-point count differs")
    required = min(6, len(full))
    prefix = full[:required] + ("\u2026" if required < len(full) else "")
    require(value.get("caller_minimum_text") == prefix,
            "Minimum readable text must be the actual first six code points and required ellipsis")
    start, omitted = value.get("caller_ellipsis_start_utf16"), value.get("caller_ellipsis_count_utf16")
    units = len(full.encode("utf-16-le")) // 2
    require(integer(start) and integer(omitted) and 0 <= start <= units and 0 <= omitted <= units,
            "Caller UTF16 ellipsis metrics out of range")
    if omitted:
        require(start + omitted == units, "END ellipsis must omit exactly the actual UTF16 suffix")
        try:
            visible = full.encode("utf-16-le")[:start * 2].decode("utf-16-le")
        except UnicodeDecodeError:
            require(False, "Caller UTF16 ellipsis cannot split a code point")
    else:
        require(start == 0, "Unellipsized caller Layout must have zero ellipsis start")
        visible = full
    require(value.get("caller_visible_prefix") == visible
            and integer(value.get("caller_visible_code_points"), len(visible)) and len(visible) >= required,
            "Actual visible caller Layout must retain six code points or the whole shorter name")
    paint, padding = value.get("caller_minimum_text_width"), value.get("caller_padding_horizontal")
    require(finite_number(paint) and paint > 0 and integer(padding) and 0 <= padding < caller[2] - caller[0],
            "Actual Paint width and caller padding must be finite, positive and bounded")
    require(caller[2] - caller[0] >= math.ceil(paint) + padding,
            "Actual caller viewport cannot contain its measured readable prefix")
    # The production capsule's184dp minimum is276px at the unchanged native
    # density. It alone exceeds this profile's176dp/264px protected lane.
    require(integer(value.get("capsule_minimum_width"), 276), "Native capsule minimum must retain184dp/276px")
    minimum = max(276, capsule[2] - capsule[0] - (caller[2] - caller[0]) + math.ceil(paint) + padding)
    require(integer(value.get("minimum_readable_width"), minimum),
            "Minimum readable width must be independently derived from actual native metrics")
    lane = 480 - 216  #144dp of production protected horizontal space at240dpi.
    require(integer(value.get("safe_lane_width"), lane), "Protected status lane width differs from the fixed native profile")
    inset = value.get("status_inset")
    require(integer(inset) and 0 < inset < 854 / 3, "Actual native status inset out of range")
    if minimum <= lane:
        require(value.get("stage") == "inapp-supported-central-status-area"
                and capsule[2] - capsule[0] <= lane and capsule[1] < inset
                and capsule[0] >= 90 and capsule[2] <= 390,
                "Supported native status capsule must fit the readable protected lane and60dp icon gaps")
    else:
        require(value.get("stage") == "inapp-protected-readable-status-fallback"
                and capsule[2] - capsule[0] >= minimum and capsule[1] >= inset + 12,
                "Unreadable native status lane must use a complete readable fallback below the bar")
    status_bar_protection(value.get("status_bar_protection"), capsule, inset)
    return inset


def status_surfaces(proof, token):
    surfaces = proof.get("surfaces", [])
    require(type(surfaces) is list and len(surfaces) == 3 and all(type(s) is dict for s in surfaces),
            "Exactly three actual external/status/default surfaces required")
    require(surfaces[0].get("stage") == "external-protected-status-fallback"
            and surfaces[1].get("stage") in {"inapp-supported-central-status-area", "inapp-protected-readable-status-fallback"}
            and surfaces[2].get("stage") == "inapp-default-below-restored",
            "Protected external/status fallback and default restoration proof missing")
    for value, overlays in zip(surfaces, (1, 0, 0)):
        rectangle(value.get("bounds"))
        require(value.get("token") == token and integer(value.get("call_state"), 4)
                and integer(value.get("external_overlay_count"), overlays), "Wrong owned island surface")
    inset = readable_status_surface(surfaces[1])
    require(rectangle(surfaces[0]["bounds"])[1] >= inset + 12,
            "External native fallback must clear protected status bar by8dp")
    require(rectangle(surfaces[2]["bounds"])[1] >= inset,
            "Default native below mode must restore placement below the status bar")
    require(proof.get("compatible_wide_native_lane") == "NOT_TESTED_FIXED_480PX_VIEWPORT",
            "Compatible wide native lane is not tested in this fixed480px viewport")


def island(proof, images):
    flags(proof, ("role_held", "hide_preserves_call_and_notification", "settings_restore_on_home",
                  "new_call_ignores_previous_hidden_token", "single_owned_surface",
                  "protected_status_icons_remain_visible", "modem_end_removes_island"))
    require(proof.get("default_dialer") == "com.dacaller.app" and "Android Telecom -> production PhoneSessionService" in proof.get("data_origin", ""), "Actual production Telecom binding missing")
    first, second = proof.get("first_token"), proof.get("second_token")
    require(isinstance(first, str) and first and isinstance(second, str) and second and first != second, "Two distinct real call tokens required")
    nex_island(proof.get("nex_active"), first, images)
    launcher = proof.get("launcher_package")
    require(isinstance(launcher, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+", launcher)
            and launcher not in {"com.dacaller.app", "com.android.systemui"}, "Resolved native Home package missing")
    foreground = proof.get("foreground_evidence", [])
    require([value.get("stage") for value in foreground] == ["active-home", "hide-home", "restore-home", "status-external", "new-call-home"], "Every named Home frame needs actual foreground evidence")
    for value in foreground:
        require(value.get("foreground_package") == launcher, "Home capture belongs to another app")
        flags(value, ("top_resumed", "native_application_window_visible"))
    answers = proof.get("answers", [])
    require([value.get("token") for value in answers] == [first, second], "Native answer must bind each distinct owned call")
    for value in answers:
        rectangle(value.get("bounds"))
        delay, stable, window = (value.get(key) for key in ("configured_touch_acceptance_delay_millis", "stable_millis", "window_id"))
        require(integer(delay) and 0 <= delay <= 3000 and integer(stable) and stable >= max(350, delay + 100)
                and integer(window) and window >= 0 and value.get("number") == "0500099971"
                and value.get("input_method") == "native-pointer" and value.get("native_caller_row") is True,
                "Native answer must use stable caller-owned SystemUI bounds beyond its actual touch guard")
    commands = proof.get("modem_commands", [])
    require([c.get("operation") for c in commands] == ["call", "cancel", "call", "cancel"], "Actual modem lifecycle required")
    require(all(isinstance(c.get("id"), str) and re.fullmatch(r"[0-9]+", c["id"]) for c in commands)
            and len({c["id"] for c in commands}) == 4 and len({c.get("serial") for c in commands}) == 1, "Unique modem acknowledgements required")
    for command in commands:
        require(command.get("number") == "0500099971" and integer(command.get("returncode"), 0)
                and re.fullmatch(r"emulator-[0-9]+", str(command.get("serial", ""))), "Invalid emulator modem acknowledgement")
        if command.get("operation") == "call":
            require("OK" in command.get("stdout", ""), "Modem call not acknowledged")
    gestures = proof.get("gestures", [])
    require([g.get("kind") for g in gestures] == ["completed_external_drag", "cancelled_external_drag", "drag_started_on_end_control"], "All real drag outcomes required")
    require(all(integer(g.get("call_state"), 4) for g in gestures), "Dragging must preserve active Telecom call")
    completed, cancelled, child = gestures
    initial, moved = rectangle(completed.get("before")), rectangle(completed.get("after"))
    require(moved[1] > initial[1] + 75 and type(completed.get("x")) is int and type(completed.get("y")) is int
            and 0 <= completed["x"] <= 10000 and 0 < completed["y"] <= 10000, "Real drag must move window and save normalized position")
    flags(cancelled, ("normalized_position_preserved", "geometry_restored"))
    require(child.get("end_confirmation_opened") is False, "Dragging End must not dispatch click")
    child_before, child_after = rectangle(child.get("before")), rectangle(child.get("after"))
    before_position, after_position = child.get("position_before"), child.get("position_after")
    require(child_after[1] > child_before[1] + 38 and integer(before_position) and integer(after_position)
            and 0 <= before_position < after_position <= 10000 and child.get("body_scrolling_required") is False,
            "Drag beginning on End must actually move and save its non-overflowing owned window")
    status_surfaces(proof, first)
    transparent = proof.get("transparency", {})
    flags(transparent, ("background_is_real_app_compositor",))
    require(type(transparent.get("view_alpha")) in (int, float) and transparent["view_alpha"] == 1
            and type(transparent.get("caller_alpha")) in (int, float) and transparent["caller_alpha"] == 1
            and integer(transparent.get("background_alpha_35"), 89) and integer(transparent.get("rgb_tolerance"), 3), "Opacity must affect background only")
    left, top, right, bottom = rectangle(transparent.get("sample_region"))
    samples = transparent.get("samples", [])
    require(len(samples) == 5 and len({(s.get("x"), s.get("y")) for s in samples}) == 5, "Five distinct real compositor samples required")
    decoded = {key: png(images[f"modern-island-{name}.png"].read_bytes(), name, True)
               for key, name in (("background", "composition-background"), ("opacity0", "opacity-0"), ("opacity35", "opacity-35"), ("opacity100", "opacity-100"))}
    for sample in samples:
        x, y = sample.get("x"), sample.get("y")
        require(type(x) is int and type(y) is int and left <= x < right and top <= y < bottom, "Sample outside actual capsule")
        for key, data in decoded.items():
            require(integer(sample.get(key)) and -(1 << 31) <= sample[key] < (1 << 31) and sample[key] & 0xffffffff == argb(data, x, y), "Reported sample differs from actual saved PNG: " + key)
        base, zero, partial, opaque = (sample[k] & 0xffffffff for k in ("background", "opacity0", "opacity35", "opacity100"))
        require(base == zero, "Zero background opacity must expose exact real underlying pixels")
        difference = 0
        for shift in (16, 8, 0):
            bg, fg, actual = (value >> shift & 255 for value in (base, opaque, partial))
            expected = int(fg * 89 / 255 + bg * 166 / 255 + 0.5)
            require(abs(expected - actual) <= 3, "35% real compositor blend does not match saved PNGs")
            difference += abs(bg - fg)
        require(difference > 80, "Samples cannot distinguish actual underlying content and opaque capsule")


def nex_island(value, token, images):
    require(type(value) is dict, "Actual NEX active Telecom island proof missing")
    require(value.get("frame") == NEX_ISLAND and NEX_ISLAND in images and value.get("style_id") == "nex"
            and value.get("language") == "he" and value.get("layout_direction") == "RTL", "NEX island must bind its Hebrew actual compositor image/style")
    require(value.get("data_origin") == "Android Telecom -> production PhoneSessionService -> live CallIslandView"
            and value.get("token") == value.get("bound_view_token") == token and bool(token)
            and integer(value.get("call_state"), 4) and integer(value.get("bound_view_state"), 4)
            and value.get("number") == "0500099971", "NEX island must retain the same owned ACTIVE Telecom call and live view token")
    flags(value, ("same_owned_call", "single_owned_surface", "preferences_restored", "previous_layout_restored"))
    require(integer(value.get("extra_modem_commands"), 0), "NEX style selection must not add modem/dial commands")
    require(rectangle(value.get("previous_bounds")) == rectangle(value.get("restored_bounds")), "NEX style preview must restore previous live layout")
    foreground = value.get("foreground", {})
    component = "com.dacaller.app/.MainActivity"
    require(foreground.get("component") == component and resumed_activity_record(foreground.get("resumed_record"), component),
            "NEX island actual production foreground Activity missing")
    flags(foreground, ("top_resumed", "native_application_window_visible"))
    require(integer(foreground.get("window_id")) and foreground["window_id"] >= 0, "NEX foreground native window missing")
    geometry = value.get("geometry", {})
    bounds = rectangle(geometry.get("bounds"))
    require(native_geometry(geometry, bounds) == foreground["window_id"], "NEX island must occupy its actual focused production window")
    for key in ("view_alpha", "scale_x", "scale_y"):
        require(finite_number(value.get(key)) and value[key] == 1, "NEX island must have stable unscaled opaque view geometry")
    for key, color in (("body_top_argb", 0xff342720), ("body_bottom_argb", 0xff241a17), ("edge_argb", 0xff634d43),
                       ("accent_argb", 0xfff6a773), ("timer_argb", 0xfff6a773)):
        require(integer(value.get(key)) and -(1 << 31) <= value[key] < (1 << 31)
                and value[key] & 0xffffffff == color, "NEX island actual view palette differs: " + key)
    samples = value.get("background_samples", [])
    require(type(samples) is list and len(samples) == 5, "NEX island real compositor samples missing")
    decoded, points = png(images[NEX_ISLAND].read_bytes(), NEX_ISLAND, True), set()
    for sample in samples:
        x, y = sample.get("x"), sample.get("y")
        require(integer(x) and integer(y), "NEX island sample coordinates must be integers")
        require(bounds[0] + 24 < x < bounds[2] - 24 and bounds[1] + 1 < y < bounds[1] + 6 and (x, y) not in points,
                "NEX island samples must lie in clear central top padding")
        require(integer(sample.get("argb")) and -(1 << 31) <= sample["argb"] < (1 << 31)
                and sample["argb"] & 0xffffffff == argb(decoded, x, y), "NEX island sample differs from actual saved PNG")
        pixel = sample["argb"] & 0xffffffff
        for shift in (16, 8, 0):
            color, top, bottom = (v >> shift & 255 for v in (pixel, 0xff342720, 0xff241a17))
            require(min(top, bottom) - 1 <= color <= max(top, bottom) + 1, "NEX island saved gradient differs from actual selected palette")
        points.add((x, y))


def legacy(baseline, all_baseline, source, app_tree):
    images = {p.name: p for p in all_baseline}
    hashes = {}
    for name, path in images.items():
        content = path.read_bytes()
        png(content, name)
        hashes[name] = hashlib.sha256(content).hexdigest()
    reports, covered = {}, set()
    for name, count in LEGACY.items():
        report = one(baseline, name)
        api = report.get("native_assertions", {}).get("api") if name == "call-integration-verification.json" else report.get("api")
        require(report.get("source_sha") == source and report.get("app_tree") == app_tree
                and integer(api, 33) and integer(report.get("required_real_png_files"), count),
                "Original gate was not completed on current source: " + name)
        if os.environ.get("GITHUB_RUN_ID") is not None:
            require(report.get("workflow_run_id") == os.environ["GITHUB_RUN_ID"], "Legacy report belongs to another workflow run: " + name)
        if name == "call-integration-verification.json":
            flags(report.get("native_assertions", {}), ("real_systemui", "notification_actions_acknowledged", "native_back_returns_to_app", "real_phone_call_foreground_service"))
        if name != "matrix-verification.json":
            saved = report.get("sha256", {})
            require(type(saved) is dict and len(saved) == count, "Missing original PNG hashes: " + name)
            for frame, digest in saved.items():
                require(frame in hashes and re.fullmatch(r"[0-9a-f]{64}", str(digest)) and digest == hashes[frame], "Original saved PNG bytes differ: " + frame)
            require(not covered.intersection(saved), "Ambiguous original report coverage: " + name)
            covered.update(saved)
        reports[name] = hashlib.sha256(json.dumps(report, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    require(len(covered) == 123, "Original complementary123-frame reports missing")
    require(one(baseline, "matrix-verification.json").get("all_files") == sorted(images), "Original matrix names differ from required native gate")
    return reports


def verify(baseline, modern, junit_root):
    require(baseline.resolve() != modern.resolve(), "Baseline and additive PNG roots must be separate")
    source = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    app_tree = subprocess.check_output(["git", "rev-parse", "HEAD:app"], text=True).strip()
    all_baseline = [p for p in baseline.rglob("*.png") if p.is_file()]
    require(len(all_baseline) == len({p.name for p in all_baseline}) == 245, "All original245 real PNGs must remain present exactly once")
    require(not any("modern-" in p.name or any(bad in p.name for bad in ("failed", "unreachable", "not-ready")) for p in all_baseline), "No additive/diagnostic filtering in original matrix")
    legacy_reports = legacy(baseline, all_baseline, source, app_tree)
    files = [p for p in modern.rglob("*.png") if p.is_file()]
    counts = collections.Counter(p.name for p in files)
    require(set(counts) == REQUIRED and all(v == 1 for v in counts.values()) and len(files) == 27, "Require exactly27 new real PNGs; no missing/duplicate/unknown diagnostic frame")
    images = {p.name: p for p in files}
    hashes = {}
    for name, path in sorted(images.items()):
        content = path.read_bytes();png(content, name);hashes[name] = hashlib.sha256(content).hexdigest()
    proofs = {}
    for name, expected in PROOFS.items():
        proof = one(modern, name)
        require(integer(proof.get("api"), 33) and integer(proof.get("density_dpi"), 240) and large_font(proof.get("font_scale"))
                and proof.get("package") == "com.dacaller.app" and proof.get("version_name") == "0.14.0" and integer(proof.get("version_code"), 23), "Wrong native package/version/configuration")
        require(proof.get("physical_carrier_audio_verified") is False and proof.get("matching_key_upgrade_verified") is False, "Emulator cannot establish hardware/audio/upgrade proof")
        captures = proof.get("captures", {})
        require(set(captures) == expected, "Exact per-scenario saved captures missing: " + name)
        for frame, value in captures.items():
            require(value.get("sha256") == hashes[frame] and integer(value.get("width"), 480) and integer(value.get("height"), 854)
                    and value.get("method") == "UiAutomation.takeScreenshot", "Real compositor saved bytes differ: " + frame)
        proofs[name] = proof
    presentation(proofs["modern-presentation-native.json"], images)
    backup(proofs["modern-backup-native.json"])
    island(proofs["modern-island-native.json"], images)
    native = junit(junit_root, Path("app/src/androidTest/java/com/dacaller/app"))
    return {"source_sha": source, "app_tree": app_tree, "workflow_run_id": os.environ.get("GITHUB_RUN_ID"),
            "api": 33, "size": "480x854", "density_dpi": 240, "font_scale": 1.3,
            "version_name": "0.14.0", "version_code": 23, "required_real_png_files": 27,
            "original_required_png_files": 245, "total_required_png_files": 272,
            "native_junit": native, "legacy_reports_canonical_sha256": legacy_reports,
            "sha256": hashes, "baseline_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in all_baseline},
            "native_assertions": proofs,
            "limits": "Fresh emulator interaction and actual production Telecom island proof. List presentation uses the explicit no-dial debug host; widget configuration uses the actual WidgetConfigure Activity with a synthetic unbound preview ID, launcher-host binding NOT_TESTED; archive uses synthetic stored rows and isolated test-provider SAF results. No human DocumentsUI, physical JellyStar/carrier/audio/overnightDoze/matching-key upgrade proof or publication authorization."}


def main():
    baseline = Path(sys.argv[1] if len(sys.argv) > 1 else "app/build/ui-snapshots")
    modern = Path(sys.argv[2] if len(sys.argv) > 2 else "app/build/ui-modern-snapshots")
    results = Path(sys.argv[3] if len(sys.argv) > 3 else "app/build/outputs/androidTest-results")
    result = verify(baseline, modern, results)
    (modern / "modern-features-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print("Verified40 authentic API33 native cases, original245frames and27additive real compositor frames (272total)")


if __name__ == "__main__":
    main()
