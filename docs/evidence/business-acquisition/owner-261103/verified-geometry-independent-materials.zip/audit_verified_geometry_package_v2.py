#!/usr/bin/env python3
"""Independent bounded source/geometry/field/database/archive audit.

Does not import the new producer or use its decisions to compute expectations.
Shares disclosed historical raw-phone parsing and numbering metadata only;
source tags, category/publicness/text/phone-v2 fields, whole geometry, SQL and
archive comparison are reconstructed here from immutable inputs.
"""
from __future__ import annotations

import argparse
import collections
import ctypes
import ctypes.util
import datetime as dt
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sqlite3
import unicodedata
import zipfile

import osmium
import phonenumbers

ROOT = Path('/workspace/D.A.-Caller')
BASE = Path('/workspace/work/business-data')
POLICY = ROOT / 'docs/business/source-geometry-admission-261103.md'
POLICY_SHA = 'c421cf24a6442f31b991037a45883234b8570e2ad82dae6cb8f673d2523e4d2c'
PBF = BASE / 'israel-and-palestine-261103.osm.pbf'
PBF_SHA = '62c6ff161b738588454719f0fd1c4971c9b46535f4ab04313e7bbe1dd582afdf'
PARENT = BASE / 'source-name-candidate-owner-261103-v1'
PARENT_SHA = '36a7c0a07fad679249c44c975cba7c8d4fb00171d593d19f4ff0c6413a0f115a'
CORPORA = {
    'node': (BASE / 'node-geography-owner-261103-v2/research-node-businesses.ndjson', '37ce40b735e144cc38eee1e72ce75c785424f0213d05c9c35feb766c1b2704df'),
    'way': (BASE / 'way-geography-owner-261103-v1/research-way-businesses.ndjson', 'cdbac300bf164e252e606d990f648c040e7193444b525786b16aba9049a692d6'),
    'relation': (BASE / 'relation-geography-owner-261103-v2/research-relation-businesses.ndjson', '2e56ba410ea38bc06897d43c50108b5d007895d41856daeffa55e136dda58ae8'),
    'extra_node': (BASE / 'extra-category-nodes-owner-261103-v2/research-extra-category-nodes.ndjson', '8f9fbe7d47041e47b38aec62f1f5b4f7b199c2671ac4b199cf4f27ec2a5a8fe8'),
    'extra_way': (BASE / 'extra-category-ways-owner-261103-v1/research-way-businesses.ndjson', 'dd35def488f06705a128986681a4d775970ad3357b55a74fecb00e63585f5df1'),
}
REGIONS = {'source_IL': 1473946, 'Gaza_admin4': 1473938,
           'JudeaSamaria_admin4_outer_filled': 1803010,
           'WestBank_historic_outer_filled': 12331025}
COUNTRY_KEYS = ('addr:country', 'country', 'is_in:country_code', 'is_in:country')
COLUMNS = ('id','name','phone','phone_display','city','category','address','source_url','source_id','source_license','source_updated_at','normalized_phone')
FALLBACKS = {'osm:node:5801536067': 'دار كنا الضيافة', 'osm:node:12543641901': 'R. Gallery Ltd'}
AMENITIES = set('bank bureau_de_change cafe restaurant fast_food food_court bar pub ice_cream pharmacy clinic doctors dentist hospital veterinary post_office car_rental car_wash fuel charging_station cinema theatre arts_centre community_centre library townhall social_facility police fire_station'.split())
TOURISM = set('hotel motel hostel guest_house apartment camp_site caravan_site attraction museum gallery theme_park zoo aquarium information'.split())
EXTRAS = {'leisure': set('fitness_centre bowling_alley escape_game trampoline_park amusement_arcade'.split()), 'amenity': set('driving_school internet_cafe nightclub'.split())}
INACTIVE = set('no vacant closed disused abandoned demolished razed'.split())


def check(value, why):
    if not value:
        raise ValueError(why)


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def hashbytes(value):
    return hashlib.sha256(value).hexdigest()


def readjson(path):
    return json.loads(Path(path).read_text())


def lines(path):
    return [json.loads(v) for v in Path(path).read_bytes().splitlines() if v]


def ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def source_category(tags):
    if tags.get('access') == 'private' or any(tags.get(k) == 'yes' for k in ('disused','abandoned','demolished','razed')):
        return None
    for key in ('shop','office','craft','healthcare'):
        if tags.get(key) and tags[key] not in INACTIVE:
            return key + ':' + tags[key]
    if tags.get('amenity') in AMENITIES:
        return 'amenity:' + tags['amenity']
    if tags.get('tourism') in TOURISM:
        return 'tourism:' + tags['tourism']
    for key, values in EXTRAS.items():
        if tags.get(key) in values:
            return key + ':' + tags[key]
    return None


def publicness(tags, category, policy):
    norm = lambda v: str(v).strip().casefold()
    flags = {norm(k): norm(v) for k,v in tags.items()}
    reasons = []
    if flags.get('access','') not in policy['access_allowed']: reasons.append('restricted-or-ambiguous-access')
    if flags.get('access:conditional',''): reasons.append('conditional-access')
    if flags.get('building','') in policy['residential_buildings'] or flags.get('residential','') in policy['residential_values_held']: reasons.append('residential-source-object')
    if flags.get('building','') in policy['nonoperating_buildings']: reasons.append('nonoperating-building')
    for prefix in policy['lifecycle_keys']:
        if flags.get(prefix,'') not in policy['lifecycle_allowed_values']: reasons.append('lifecycle-flag:' + prefix)
        if any(k.startswith(prefix+':') and v for k,v in flags.items()): reasons.append('lifecycle-prefixed-tag:' + prefix)
    if norm(category.split(':',1)[-1]) in policy['inactive_category_values']: reasons.append('inactive-category-value')
    return sorted(reasons)


def clean(value):
    return unicodedata.normalize('NFC', value).strip()


def safe(value, maximum, optional=False):
    return (isinstance(value,str) and value == clean(value) and (optional or bool(value))
            and len(value.encode('utf-16-le')) // 2 <= maximum
            and all(unicodedata.category(c) not in {'Cc','Cf','Cs'} for c in value))


def national(value):
    if not isinstance(value,str): return ''
    value = value.strip(''.join(chr(n) for n in range(33))).replace('\u00a0',' ')
    if re.fullmatch(r'[+*0-9() .\-]+',value,re.ASCII) is None: return ''
    value = re.sub('[^0-9+*]','',value,flags=re.ASCII)
    for prefix in ('+972','00972','972'):
        if value.startswith(prefix):
            value=value[len(prefix):]
            value = value if not value or value.startswith('1') else '0'+value
            break
    return value


def normal(value):
    value=national(value)
    return value if re.fullmatch(r'0(?:[2-489][0-9]{7}|[57][0-9]{8})|\*[0-9]{3,6}|1[0-9]{2,9}',value,re.ASCII) else ''


def raw_key(row):
    return hashbytes(json.dumps([row['source_id'],row['phone'],row['extension']],ensure_ascii=True,separators=(',',':')).encode())


def source_read(ids):
    found={}
    numeric={int(v.rsplit(':',1)[1]) for v in ids}
    class Read(osmium.SimpleHandler):
        def retain(self,obj,kind):
            key=f'osm:{kind}:{obj.id}'
            if key not in ids: return
            check(key not in found,'Repeated source object')
            data={'source_id':key,'tags':dict(obj.tags),'timestamp':obj.timestamp.isoformat(),'version':obj.version}
            if kind=='node':
                check(obj.location.valid(),'Invalid source point')
                data.update(longitude=obj.location.lon,latitude=obj.location.lat)
            elif kind=='way': data['refs']=[v.ref for v in obj.nodes]
            else: data['members']=[{'type':m.type,'ref':m.ref,'role':m.role} for m in obj.members]
            found[key]=data
        def node(self,obj): self.retain(obj,'node')
        def way(self,obj): self.retain(obj,'way')
        def relation(self,obj): self.retain(obj,'relation')
    osmium.apply(str(PBF),osmium.filter.IdFilter(numeric),Read())
    check(set(found)==set(ids),'Missing actual source objects')
    return found


class Geometry:
    """Audit-owned GEOS bindings and containment/distance predicates."""
    def __init__(self, rings):
        g=self.g=ctypes.CDLL(ctypes.util.find_library('geos_c'))
        p=ctypes.c_void_p
        g.initGEOS.argtypes=[p,p];g.initGEOS(None,None)
        g.GEOSversion.restype=ctypes.c_char_p
        self.version=g.GEOSversion().decode()
        g.GEOSWKTReader_create.restype=p
        g.GEOSWKTReader_read.argtypes=[p,ctypes.c_char_p];g.GEOSWKTReader_read.restype=p
        g.GEOSGeom_destroy.argtypes=[p];g.GEOSWKTReader_destroy.argtypes=[p]
        g.GEOSBoundary.argtypes=[p];g.GEOSBoundary.restype=p
        for name in ('GEOSContains','GEOSIntersects'):
            getattr(g,name).argtypes=[p,p];getattr(g,name).restype=ctypes.c_char
        for name in ('GEOSisValid','GEOSisEmpty'):
            getattr(g,name).argtypes=[p];getattr(g,name).restype=ctypes.c_char
        for name in ('GEOSArea','GEOSDistance'):
            getattr(g,name).argtypes=([p] if name=='GEOSArea' else [p,p])+[ctypes.POINTER(ctypes.c_double)]
            getattr(g,name).restype=ctypes.c_int
        self.reader=g.GEOSWKTReader_create()
        self.regions={name:self.read('POLYGON ('+self.ring(rings[name][0]['coordinates'])+')',True) for name in REGIONS}
        self.boundary=g.GEOSBoundary(self.regions['source_IL'])
    @staticmethod
    def ring(coords):
        check(len(coords)>=4 and coords[0]==coords[-1],'Open/short ring')
        check(all(len(c)==2 and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in c) and -180<=c[0]<=180 and -90<=c[1]<=90 for c in coords),'Invalid ring coordinate')
        return '('+','.join(f'{c[0]} {c[1]}' for c in coords)+')'
    def area(self, geom):
        result=ctypes.c_double();check(self.g.GEOSArea(geom,ctypes.byref(result))==1,'Area failed');return result.value
    def read(self,wkt,area=False):
        ptr=self.g.GEOSWKTReader_read(self.reader,wkt.encode())
        check(ptr and self.g.GEOSisValid(ptr)==b'\x01' and self.g.GEOSisEmpty(ptr)==b'\x00','Invalid/empty geometry')
        if area: check(self.area(ptr)>0,'Nonpositive polygon area')
        return ptr
    def pred(self,method,a,b):
        result=getattr(self.g,method)(a,b);check(result in (b'\x00',b'\x01'),'Predicate failed');return result==b'\x01'
    def dist(self,a,b):
        value=ctypes.c_double();check(self.g.GEOSDistance(a,b,ctypes.byref(value))==1 and math.isfinite(value.value),'Distance failed');return value.value
    def check(self,pointer):
        check(self.pred('GEOSContains',self.regions['source_IL'],pointer),'Geometry outside/on IL source')
        distances={'source_IL_boundary':self.dist(self.boundary,pointer)}
        for name in REGIONS:
            if name=='source_IL':continue
            check(not self.pred('GEOSIntersects',self.regions[name],pointer),'Geometry intersects filled exclusion')
            distances[name]=self.dist(self.regions[name],pointer)
        check(all(v>0.001 for v in distances.values()),'Angular margin failed')
        return distances
    def close(self):
        for p in [self.boundary,*self.regions.values()]:self.g.GEOSGeom_destroy(p)
        self.g.GEOSWKTReader_destroy(self.reader)


def edges(refs):
    return collections.Counter(tuple(sorted((a,b))) for a,b in zip(refs,refs[1:]))


def geometry_sources(source, region_rings):
    # Independently check reviewed region outer rings against actual PBF ways,
    # nodes and source relation memberships, not only retained inventory labels.
    relation_ids={'osm:relation:'+str(v) for v in REGIONS.values()}
    extra_relations=source_read(relation_ids)
    way_ids={v['ref'] for s in source.values() if s['source_id'].startswith('osm:relation:') for v in s['members'] if v['type']=='w'}
    way_ids.update(int(s.rsplit(':',1)[1]) for s in source if s.startswith('osm:way:'))
    way_ids.update(w for name in REGIONS for ring in region_rings[name] for w in ring['ways'])
    actual_ways=source_read({'osm:way:'+str(v) for v in way_ids})
    node_ids={ref for way in actual_ways.values() for ref in way['refs']}
    actual_nodes=source_read({'osm:node:'+str(v) for v in node_ids})
    coordinates={int(s.rsplit(':',1)[1]):[v['longitude'],v['latitude']] for s,v in actual_nodes.items()}
    for name,rel_id in REGIONS.items():
        check(len(region_rings[name])==1,'Source ring count changed')
        ring=region_rings[name][0]
        actual_relation=extra_relations['osm:relation:'+str(rel_id)]
        refs={m['ref'] for m in actual_relation['members'] if m['type']=='w' and m['role'] in ('outer','')}
        check(refs==set(ring['ways']),'Reviewed region ways differ from actual relation outer membership')
        if name=='source_IL': check(not any(m['role']=='inner' for m in actual_relation['members']),'Unrepresented IL source hole')
        check(ring['node_ids'][0]==ring['node_ids'][-1],'Region node ring open')
        check([coordinates[n] for n in ring['node_ids']]==ring['coordinates'],'Region coordinates differ from actual PBF nodes')
        expected=collections.Counter()
        for w in ring['ways']:expected.update(edges(actual_ways['osm:way:'+str(w)]['refs']))
        check(edges(ring['node_ids'])==expected,'Region ring invents/omits actual source edges')
    return actual_ways,coordinates,{'actual_region_relations':len(extra_relations),'actual_support_ways':len(actual_ways),'actual_support_nodes':len(actual_nodes)}


def evaluate_geometry(source,ways,coordinates,rings,retained):
    g=Geometry(rings); evaluated={};kinds=collections.Counter()
    try:
        for sid,obj in source.items():
            kind=sid.split(':')[1]
            if kind=='node':
                ptr=g.read(f"POINT ({obj['longitude']} {obj['latitude']})")
            elif kind=='way':
                check(obj==ways[sid],'Actual way rereads disagree')
                coords=[coordinates[n] for n in obj['refs']]
                check(len(set(obj['refs'][:-1]))==len(obj['refs'])-1,'Self-repeating way topology')
                ptr=g.read('POLYGON ('+g.ring(coords)+')',True)
                check(retained[sid]['source_node_refs']==obj['refs'] and retained[sid]['source_coordinates']==coords,'Retained full source way differs')
            else:
                # This bounded admitted relation has exactly one complete outer
                # way and one complete inner way; no generalized repair/join.
                members=obj['members'];check(len(members)==2 and {m['role'] for m in members}=={'outer','inner'} and all(m['type']=='w' for m in members),'Bounded true-hole topology changed')
                role={m['role']:ways['osm:way:'+str(m['ref'])] for m in members}
                role_coords={k:[coordinates[n] for n in w['refs']] for k,w in role.items()}
                outer=g.read('POLYGON ('+g.ring(role_coords['outer'])+')',True)
                inner=g.read('POLYGON ('+g.ring(role_coords['inner'])+')',True)
                boundary=g.g.GEOSBoundary(outer)
                try:
                    check(g.pred('GEOSContains',outer,inner) and g.dist(boundary,inner)>0,'Source hole not strictly contained')
                    ptr=g.read('POLYGON ('+g.ring(role_coords['outer'])+','+g.ring(role_coords['inner'])+')',True)
                    check(math.isclose(g.area(ptr),g.area(outer)-g.area(inner),rel_tol=1e-9,abs_tol=1e-15),'True source hole was filled/distorted')
                finally:
                    for p in (outer,inner,boundary):g.g.GEOSGeom_destroy(p)
                retained_rings=retained[sid]['retained_geometry']
                for k in ('outer','inner'):
                    check(len(retained_rings[k])==1 and retained_rings[k][0]['node_refs']==role[k]['refs'] and retained_rings[k][0]['coordinates']==role_coords[k],'Retained true-hole source geometry differs')
                check(retained_rings['inner_to_outer_indices']==[0],'Source hole assignment changed')
            try:
                distances=g.check(ptr)
                if kind!='relation':
                    stored=retained[sid]['source_distances_lonlat_degrees']
                    check(set(stored)==set(distances) and all(math.isclose(distances[k],stored[k],rel_tol=1e-12,abs_tol=1e-12) for k in distances),'Retained spatial distances differ')
                evaluated[sid]=distances;kinds[kind]+=1
            finally:g.g.GEOSGeom_destroy(ptr)
        return dict(objects_replayed=len(evaluated),objects_by_kind=dict(kinds),geos_version=g.version,complete_true_hole_relations=kinds['relation'],minimum_angular_distances={k:min(v[k] for v in evaluated.values()) for k in next(iter(evaluated.values()))})
    finally:g.close()


def main(package, report_path):
    package=Path(package).resolve();report_path=Path(report_path).resolve()
    check(not report_path.exists(),'Never overwrite independent evidence')
    bind=readjson(package/'input-binding.json')
    check(bind and all(sha(path)==expected for path,expected in bind.items()),'A producer-bound input currently differs')
    own={Path(__file__):sha(__file__),POLICY:sha(POLICY),PBF:sha(PBF),PARENT/'candidate-businesses.sqlite':sha(PARENT/'candidate-businesses.sqlite')}
    check(own[POLICY]==POLICY_SHA and own[PBF]==PBF_SHA and own[PARENT/'candidate-businesses.sqlite']==PARENT_SHA,'Immutable anchor differs')
    policy=json.loads(re.search(r'```json\n(.*?)\n```',POLICY.read_text(),re.S)[1])
    check(policy['authorizes_publication_or_signing_exception'] is False,'Policy approval scope changed')
    check((package/'redistribution/source-geometry-admission-policy.md').read_bytes()==POLICY.read_bytes() and readjson(package/'redistribution/effective-admission-policy.json')==policy,'Redistributed admission policy differs')
    check((package/'redistribution/owner-upload-receipt.json').read_bytes()==(BASE/'owner-upload-receipt.json').read_bytes() and readjson(package/'redistribution/owner-upload-receipt.json')['publisher_provenance_independently_verified'] is False,'Owner transfer receipt/provenance changed')
    source_zip=PBF.with_suffix('.zip')
    check(sha(source_zip)=='578d67213db0cb617f18ccd12c60eab5c532f073fa5520b399d9f5d36973b11e','Original uploaded ZIP hash differs')
    own[source_zip]=sha(source_zip)
    with zipfile.ZipFile(source_zip) as archive:
        names=[n for n in archive.namelist() if n.endswith('.osm.pbf')]
        check(archive.testzip() is None and len(names)==1,'Original source ZIP CRC/member identity differs')
        with archive.open(names[0]) as member:check(hashlib.file_digest(member,'sha256').hexdigest()==PBF_SHA,'Original source ZIP member differs from actual PBF')
    records=[]
    for family,(path,expected) in CORPORA.items():
        check(sha(path)==expected,'Original cohort changed');own[path]=expected
        data=path.read_bytes();check((package/'redistribution/original-cohorts'/f'{family}.ndjson').read_bytes()==data,'Redistributed original raw lines changed')
        for ordinal,line in enumerate(data.splitlines(keepends=True)):records.append((family,ordinal,line,json.loads(line)))
    check(len(records)==2728,'Bounded raw count differs')
    with ro(PARENT/'candidate-businesses.sqlite') as parent:
        parent.row_factory=sqlite3.Row
        originals={(r['corpus_kind'],r['ordinal']):(bytes(r['original_line']),r['record_key']) for r in parent.execute('select * from candidate_raw_records')}
        old_decisions={r['record_key']:dict(r) for r in parent.execute('select * from candidate_decisions')}
        previous={r['id']:tuple(r) for r in parent.execute('select '+','.join(COLUMNS)+' from businesses')}
    for family,ordinal,line,row in records:check(originals[(family,ordinal)]==(line,raw_key(row)),'Raw source/history identity differs')
    for name in ('candidate-decisions.ndjson','candidate-source-name-selections.ndjson','input-binding.json','source-name-input-binding.json','candidate-reader-manifest.json','candidate-review-envelope.json','LICENSE-NOTICE.txt'):
        check((package/'redistribution'/name).read_bytes()==(PARENT/name).read_bytes(),'Historical artifact was rewritten: '+name)
    historical=readjson(package/'redistribution/historical-reference-resolutions.json')
    check(len(historical)==1 and historical[0]['historical_git_source']=='0d266d63d446b46d3e2a98048b112572d22768fa','Historical reader reference substitution differs')
    check(Path(historical[0]['original_path']).name=='BusinessDirectory.java' and Path(historical[0]['verified_historical_path']).name=='008-BusinessDirectory.java' and sha(historical[0]['verified_historical_path'])==historical[0]['expected_sha256'],'Historical Java reference not exact')
    current_reader=ROOT/'app/src/main/java/com/dacaller/app/BusinessDirectory.java'
    check(str(current_reader) in bind and sha(current_reader)==bind[str(current_reader)],'Current reader not independently bound')
    core=module('independent_old_phone_reference',ROOT/'scripts/business-directory/extract_osm_businesses.py')
    helper=module('independent_current_v2_comparison',ROOT/'scripts/business-directory/business_phone_v2.py')
    check(phonenumbers.__version__=='9.0.42','Numbering metadata version differs')
    source=source_read({r['source_id'] for *_,r in records});check(len(source)==2668,'Actual source count differs')
    retained_objects={r['source_id']:r for r in lines(package/'redistribution/fresh-source-objects.ndjson')}
    check(set(retained_objects)==set(source),'Retained actual source set differs')
    for sid,actual in source.items():
        retained=retained_objects[sid]
        check(all(retained[k]==v for k,v in actual.items()) and retained['source_pbf_sha256']==PBF_SHA,'Fresh full source tags/metadata differ: '+sid)
        cat=source_category(actual['tags']);check(cat is not None and retained['reviewed_category']==cat,'Independent category differs')
        check(retained['publicness_holds']==publicness(actual['tags'],cat,policy),'Independent publicness differs')
    rings=readjson(BASE/'research-region-outer-rings.json')
    actual_ways,coordinates,support=geometry_sources(source,rings)
    retained_geo=readjson(package/'redistribution/fresh-geometry-replay.json')
    check(set(retained_geo['objects'])==set(source),'Retained geometry object set differs')
    check(all(sha(BASE/name)==expected and bind[str(BASE/name)]==expected for name,expected in retained_geo['provenance']['input_sha256'].items()),'Retained geometry provenance bindings differ')
    geometry=evaluate_geometry(source,actual_ways,coordinates,rings,retained_geo['objects'])
    ledger=lines(package/'redistribution/new-admission-decisions.ndjson')
    check(len(ledger)==2728 and len({x['record_key'] for x in ledger})==2728,'Ledger count/uniqueness differs')
    decisions={x['record_key']:x for x in ledger}
    projected=[];admitted=[];held=[];phone_checks=0;publicness_held=[]
    for family,ordinal,line,row in records:
        sid=row['source_id'];tags=source[sid]['tags'];event=decisions[raw_key(row)];cat=source_category(tags)
        check((event['corpus_kind'],event['ordinal'],event['source_id'],event['original_line_sha256'])==(family,ordinal,sid,hashbytes(line)),'New ledger raw/source binding differs')
        check(event['prior_decision']==old_decisions[raw_key(row)] and event['original_country']==row['country_tag'] and event['original_country_fields']==row['source_country_fields'] and event['original_scope']==row['geographic_scope'] and event['original_phone']==row['phone'] and event['original_extension']==row['extension'],'Old decision/source fields changed')
        check(event['source_mutations']==0 and event['production_publication'] is False and event['source_geometry_replayed'] is True and event['fresh_source_tags_replayed'] is True and event['policy_id']==policy['policy_id'] and event['admission_method']==policy['admission_scope'] and event['source_pbf_sha256']==PBF_SHA,'New admission method/proof scope differs')
        name=next((clean(tags[k]) for k in ('name:he','name','name:en') if tags.get(k,'').strip()),'');city=clean(tags.get('addr:city',''))
        address=clean(tags.get('addr:full','')) or ' '.join(v for v in (clean(tags.get('addr:street','')),clean(tags.get('addr:housenumber','')),city) if v)
        check((row['name'],row['category'],row['city'],row['address'],row['source_updated_at'])==(name,cat,city,address,source[sid]['timestamp']),'Raw display/category/date differs from fresh PBF')
        check(row.get('source_version',source[sid]['version'])==source[sid]['version'],'Available raw source version changed')
        check(all(tags.get(k)==v for field in ('source_tags','source_names') for k,v in row.get(field,{}).items()),'Raw source tags/names changed')
        if sid.startswith('osm:node:'):
            check((row['longitude'],row['latitude'])==(source[sid]['longitude'],source[sid]['latitude']),'Raw point coordinates differ from PBF')
        elif sid.startswith('osm:way:'):
            check(row['source_node_refs']==source[sid]['refs'] and row['complete_source_ring_coordinates']==[coordinates[n] for n in source[sid]['refs']],'Raw complete way references/coordinates differ from PBF')
        else:
            check(row['relation_geometry']==retained_geo['objects'][sid]['retained_geometry'],'Raw true-hole relation projection differs')
        fields={k:tags[k] for k in COUNTRY_KEYS if tags.get(k)};countries=[tags[k].strip().upper() for k in COUNTRY_KEYS if tags.get(k,'').strip()]
        check(row['source_country_fields']==fields and row['country_tag']==(countries[0] if countries else None) and all(v in {'IL','ISR','ISRAEL','ישראל'} for v in countries),'Country field/NULL manufacturing')
        check(row['source_url']=='https://www.openstreetmap.org/'+sid.split(':')[1]+'/'+sid.split(':')[2] and row['license_id']=='ODbL-1.0' and row['verification']=='source-listed-not-phone-confirmed','Source provenance differs')
        actual_phones=[p for k in ('contact:phone','phone') if tags.get(k) for p in core.phones(tags[k])[0]]
        check(any(all(row[k]==p[k] for k in ('phone','e164','extension','original_phone','phone_type','dialing_scope')) for p in actual_phones),'Raw phone not exactly parsed from PBF tag')
        check(row['extension']=='','Native cannot represent a separate extension')
        canonical=normal(row['phone']);check(canonical and canonical==helper.normalized_phone(row['phone']),'Independent native phone-v2 grammar differs')
        parsed=phonenumbers.parse(row['phone'],'IL');e164=phonenumbers.format_number(parsed,phonenumbers.PhoneNumberFormat.E164)
        check(parsed.country_code==972 and phonenumbers.is_valid_number_for_region(parsed,'IL') and row['e164']==e164,'Source phone allocation/E.164 differs')
        check(phonenumbers.format_number(phonenumbers.parse(canonical,'IL'),phonenumbers.PhoneNumberFormat.E164)==e164,'Canonical dial identity differs')
        aliases=(e164,'00972'+e164[4:],'972'+e164[4:],phonenumbers.format_number(parsed,phonenumbers.PhoneNumberFormat.NATIONAL))
        check(all(normal(a)==canonical and helper.normalized_phone(a)==canonical and helper.phone_prefix(a)==canonical for a in aliases),'International/national source identity/query aliases differ');phone_checks+=len(aliases)+1
        if sid in FALLBACKS:
            check(tags['name']==FALLBACKS[sid] and row['source_names']['name']==FALLBACKS[sid],'Exact source-name fallback changed');name=FALLBACKS[sid]
        reasons=publicness(tags,cat,policy)
        if reasons:publicness_held.append(sid)
        unsafe=sid=='osm:node:5066707334' or not all((safe(name,300),safe(row['phone'],80),safe(city,300,True),safe(cat,300,True),safe(address,1200,True),safe(row['source_updated_at'],80)))
        if reasons or unsafe:
            check(event['decision']=='WITHHELD' and event['projected_business_id'] is None and event['hold_reasons'],'Independent hold was admitted')
            check(set(reasons)<=set(event['hold_reasons']),'Missing source hold explanation');held.append(raw_key(row));continue
        check(event['decision']=='ADMITTED_FOR_NATIVE_EVALUATION' and event['hold_reasons']==[],'Independently valid row unexpectedly withheld')
        check(event['prior_phone_hold_resolved']==(old_decisions[raw_key(row)]['decision']=='WITHHELD_PHONE_FORMAT_REVIEW'),'Individual prior phone-hold resolution differs')
        if sid in FALLBACKS:
            check(event['source_name_choice']=={'selected_tag':'name','selected_value':FALLBACKS[sid],'original_preferred_name':row['name'],'original_line_sha256':hashbytes(line),'source_text_report_sha256':'e04848419c58d79e9d3e5eeab9c3e778cfa3f223554966f374625d4bd3a299fc'},'Exact source-name selection event differs')
        else:check(event['source_name_choice'] is None,'Unauthorized source-name selection event')
        stable=int.from_bytes(hashlib.sha256((sid+':'+canonical).encode()).digest()[:8],'big')&((1<<63)-1)
        value=(stable,name,row['phone'],row['phone'],city,cat,address,row['source_url'],sid,'ODbL-1.0',row['source_updated_at'],canonical)
        check(event['projected_business_id']==stable and event['normalized_phone']==canonical,'Stable/dial ledger identity differs')
        if stable in previous:check(value==previous[stable],'Previously projected fields changed')
        projected.append(value);admitted.append((family,row,event))
    check(len(projected)==2720 and len(held)==8 and len(publicness_held)==7,'Independent measured source decision totals differ')
    check(len({v[0] for v in projected})==len(projected) and len({(v[8],v[11]) for v in projected})==len(projected),'Source identity collision or merge')
    database=package/'app-assets/business-directory/israel-businesses.sqlite';manifest=readjson(database.with_name('manifest.json'));report=readjson(package/'verification-report.json')
    db_sha=sha(database);own[database]=db_sha
    check(manifest['database_sha256']==db_sha and manifest['record_count']==len(projected) and type(manifest['record_count']) is int and manifest['schema_version']==1 and type(manifest['schema_version']) is int and manifest['format']=='DA_CALLER_BUSINESSES' and manifest['license']=='ODbL-1.0' and manifest['updated_at']=='2026-11-03','Native manifest truth differs')
    check(manifest['source_name']=='OpenStreetMap — © OpenStreetMap contributors' and manifest['source_url']=='https://download.geofabrik.de/asia/israel-and-palestine.html' and manifest['license_url']=='https://opendatacommons.org/licenses/odbl/1-0/' and re.fullmatch(r'[A-Za-z0-9._-]{1,80}',manifest['dataset_version']) and database.stat().st_size<=512*1024*1024,'Native attribution/source/license/version/size contract differs')
    notice=database.with_name('NOTICE.txt').read_text()
    check('© OpenStreetMap contributors' in notice and 'ODbL-1.0' in notice and 'https://opendatacommons.org/licenses/odbl/1-0/' in notice,'Asset attribution/license notice missing')
    check('docs/evidence/business-acquisition/owner-261103/verified-geometry-README.md' in notice,'Corresponding source distribution location missing from asset notice')
    check(report['database_sha256']==db_sha and report['database_bytes']==database.stat().st_size and report['policy_sha256']==POLICY_SHA and report['native_reader_sha256']==sha(current_reader),'Producer final reader/data bindings differ')
    check(report['production_publication'] is False and report['app_assets_installed'] is False and report['apk_changed'] is False and report['publisher_provenance_independently_verified'] is False,'Producer approval/provenance scope changed')
    with ro(database) as db:
        check(db.execute('pragma integrity_check').fetchone()[0]=='ok' and not db.execute('pragma foreign_key_check').fetchall() and db.execute('pragma user_version').fetchone()[0]==1,'SQLite integrity/version failed')
        tables={v[0] for v in db.execute("select name from sqlite_master where type='table'")}
        check(tables=={'metadata','businesses','business_search','business_search_content','business_search_segments','business_search_segdir','business_search_docsize','business_search_stat'},'Research/history/incompatible native table')
        check(tuple(v[1] for v in db.execute('pragma table_info(businesses)'))==COLUMNS,'Native12column schema differs')
        check(db.execute('select '+','.join(COLUMNS)+' from businesses order by id').fetchall()==sorted(projected),'Native fields differ from independent PBF projection')
        search=lambda v:''.join(c for c in unicodedata.normalize('NFKD',v) if not unicodedata.category(c).startswith('M'))
        expected_fts=[(v[0],search(v[1]),search(v[4]),search(v[5]),v[11]) for v in sorted(projected)]
        check(db.execute('select docid,name,city,category,phone from business_search order by docid').fetchall()==expected_fts,'FTS projection differs')
        check(db.execute("select value from metadata where key='dataset_version'").fetchone()[0]==manifest['dataset_version'],'Dataset version metadata differs')
        for value in projected:
            check(db.execute('select id from businesses where id=? and normalized_phone=?',(value[0],value[11])).fetchone()==(value[0],),'Exact SQL phone lookup missing source identity')
            check(db.execute('select docid from business_search where docid=? and business_search match ?',(value[0],'phone:'+value[11])).fetchone()==(value[0],),'Exact SQL FTS lookup missing source identity')
    phones=collections.Counter(v[11] for v in projected)
    counts={'raw_rows':2728,'raw_source_objects':2668,'raw_null_countries':sum(r['country_tag'] is None for *_,r in records),'projected_rows':len(projected),'projected_source_objects':len({v[8] for v in projected}),'projected_dial_identities':len(phones),'shared_phone_groups':sum(v>1 for v in phones.values()),'projected_raw_null_countries':sum(r['country_tag'] is None for _,r,_ in admitted),'withheld_rows':len(held),'categories':dict(sorted(collections.Counter(v[5] for v in projected).items())),'admitted_rows_by_cohort':dict(sorted(collections.Counter(family for family,_,_ in admitted).items())),'exact_source_name_choices':sum(r['source_id'] in FALLBACKS for _,r,_ in admitted),'admitted_previously_phone_held_rows':sum(e['prior_decision']['decision']=='WITHHELD_PHONE_FORMAT_REVIEW' for _,_,e in admitted)}
    for key,value in counts.items():check(report['counts'][key]==value,'Measured report count differs: '+key)
    coverage=readjson(package/'redistribution/coverage.json')
    check(coverage['counts']==report['counts'] and coverage['national_coverage_denominator'] is None and coverage['national_coverage_percentage'] is None and coverage['current_phone_ownership_verified'] is False and coverage['publisher_origin_independently_authenticated'] is False,'Coverage/currentness overclaim')
    check(coverage['source_edit_date_min']==min(v[10] for v in projected) and coverage['source_edit_date_max']==max(v[10] for v in projected),'Source dates differ')
    inventory=readjson(package/'artifact-inventory.json')
    check({str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}==set(inventory)|{'artifact-inventory.json','redistributable-source-and-dataset.zip'},'Package has unlisted artifacts')
    check(all(sha(package/relative)==v['sha256'] and (package/relative).stat().st_size==v['bytes'] for relative,v in inventory.items()),'Retained artifact inventory differs')
    with zipfile.ZipFile(package/'redistributable-source-and-dataset.zip') as archive:
        check(archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist())) and set(archive.namelist())==set(inventory)|{'artifact-inventory.json'},'Redistribution ZIP members/CRC differ')
        check(all(archive.read(relative)==(package/relative).read_bytes() for relative in archive.namelist()),'Redistribution ZIP bytes differ from audited output')
    for index,(path,expected) in enumerate(sorted(bind.items())):
        if Path(path).stat().st_size<=2_000_000:
            check(sha(package/'redistribution/bound-evidence'/f'{index:03d}-{Path(path).name}')==expected,'Retained bound proof/source code differs')
    check(all(sha(path)==value for path,value in bind.items()) and all(sha(path)==value for path,value in own.items()),'Input/output drift during independent audit')
    result={'status':'PASS_FULL_BOUNDED_DATA_AUDIT_NATIVE_HOST_GATE_SEPARATE','publication_authorized':False,'asset_copy_permission':'CONDITIONAL_ON_SEPARATE_CURRENT_READER_HOST_PROOF','observed_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'policy_sha256':POLICY_SHA,'source_pbf_sha256':PBF_SHA,'parent_candidate_sha256':PARENT_SHA,'package_path':str(package),'database_sha256':db_sha,'database_bytes':database.stat().st_size,'native_reader_sha256':sha(current_reader),'auditor_sha256':sha(__file__),'producer_sha256':sha(ROOT/'scripts/business-directory/package_verified_geometry_dataset.py'),'redistribution_zip_sha256':sha(package/'redistributable-source-and-dataset.zip'),'manifest_sha256':sha(database.with_name('manifest.json')),'input_bindings_compared':len(bind),'counts':counts,'independent_geometry':geometry,'fresh_pbf_geometry_support':support,'all_raw_rows_original_bytes_history_country_fields_preserved':2728,'all_actual_pbf_source_tags_category_access_lifecycle_name_city_address_url_license_phone_dates_replayed':2728,'all_native12column_projected_rows_and_fts_compared':len(projected),'all_exact_sql_phone_and_fts_queries':2*len(projected),'independent_current_phone_v2_source_alias_checks':phone_checks,'new_publicness_held_source_ids':sorted(set(publicness_held)),'unsafe_city_address_remains_held':'osm:node:5066707334','exact_source_name_fallbacks':FALLBACKS,'historical_native_reference_resolutions':historical,'source_and_dependencies_drift_checked_before_after':True,'zip_members_exact_bytes_crc_inventory':True,'original_uploaded_zip_crc_and_pbf_member_hash_rechecked':True,'native_attribution_and_corresponding_materials_location_checked':True,'limitations':['Current actual-reader host checks are separately owned; no emulator/UI/Telecom tests performed by this auditor.','Historical core raw-phone tokenizer and phonenumbers9.0.42 metadata are disclosed shared contracts; no current ownership/reachability or national completeness claim.','Native phone-v2 expectations, publicness, text, all field projections, GEOS bindings/whole geometries and SQL/archive comparisons were independently implemented here, not called from new producer.','No future signing exception/publication permission; immutable0.12.0 APK/evidence untouched.','Physical hardware and matching-key upgrade remain NOT TESTED.']}
    report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','database_sha256','counts','fresh_pbf_geometry_support','input_bindings_compared')},ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('package',type=Path);parser.add_argument('report',type=Path);args=parser.parse_args();main(args.package,args.report)
