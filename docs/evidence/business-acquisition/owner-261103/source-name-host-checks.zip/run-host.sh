#!/usr/bin/env bash
set -e
source /workspace/toolchains/activate.sh
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Duser.home=/workspace/D.A.-Caller/work/robolectric-home"
gradle --offline --no-daemon -I /workspace/work/source-name-reader-tests/init.gradle -Dcandidate.database=/workspace/work/business-data/source-name-candidate-owner-261103-v1/candidate-businesses.sqlite -Dcandidate.manifest=/workspace/work/business-data/source-name-candidate-owner-261103-v1/candidate-reader-manifest.json -Dcandidate.sha256=36a7c0a07fad679249c44c975cba7c8d4fb00171d593d19f4ff0c6413a0f115a -Dcandidate.output=/workspace/work/source-name-reader-tests :app:testDebugUnitTest --tests com.dacaller.app.SourceNameReaderHostContractTest --console=plain
