package com.dacaller.app;

import static org.junit.Assert.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.*;
import org.json.JSONObject;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;

/** Explicit outside-app candidate contract observation; not native/emulator admission. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=33)
@SQLiteMode(SQLiteMode.Mode.NATIVE)
public class CandidateReaderHostContractTest {
 private static final JSONObject observations = new JSONObject();
 private File source,root,canary; private byte[] manifestBytes; private String sourceHash;
 private BusinessDirectory.Manifest manifest;
 @Before public void setup() throws Exception {
  source=new File(required("candidate.database"));
  sourceHash=required("candidate.sha256");assertEquals(sourceHash,hash(source));
  manifestBytes=Files.readAllBytes(Paths.get(required("candidate.manifest")));
  manifest=read(manifestBytes);assertEquals(sourceHash,manifest.sha256);
  root=Files.createTempDirectory(RuntimeEnvironment.getApplication().getCacheDir().toPath(),"outside-app-candidate-").toFile();
  canary=new File(root,"private-archive-canary.sqlite");Files.write(canary.toPath(),new byte[]{11,21,31,41});
 }
 @After public void inputAndCanaryUnchanged() throws Exception {
  assertEquals(sourceHash,hash(source));assertArrayEquals(new byte[]{11,21,31,41},Files.readAllBytes(canary.toPath()));
 }
 @AfterClass public static void retainObservations() throws Exception {
  observations.put("environment","HOST_ROBOLECTRIC_API33_NATIVE_SQLITE");
  observations.put("android_emulator",false);observations.put("telecom_tested",false);
  observations.put("production_admission",false);observations.put("publication_approval",false);
  observations.put("app_records_added",0);observations.put("source_database_sha256",required("candidate.sha256"));
  Path output=Paths.get(required("candidate.output"));Files.createDirectories(output);
  Files.write(output.resolve("host-observations.json"),(observations.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));
 }
 private static String required(String key){String value=System.getProperty(key);if(value==null||value.isEmpty())throw new IllegalStateException(key+" required");return value;}
 private static String hash(File file)throws Exception {MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] buf=new byte[65536];for(int n;(n=in.read(buf))!=-1;)d.update(buf,0,n);}StringBuilder out=new StringBuilder();for(byte b:d.digest())out.append(String.format(Locale.ROOT,"%02x",b&255));return out.toString();}
 private static BusinessDirectory.Manifest read(byte[] bytes)throws Exception{return BusinessDirectory.readManifest(new ByteArrayInputStream(bytes));}
 private JSONObject json()throws Exception{return new JSONObject(new String(manifestBytes,StandardCharsets.UTF_8));}
 private BusinessDirectory.Manifest modifiedManifest(JSONObject json)throws Exception{return read(json.toString().getBytes(StandardCharsets.UTF_8));}
 private SQLiteDatabase open(){return SQLiteDatabase.openDatabase(source.getPath(),null,SQLiteDatabase.OPEN_READONLY);}
 private File install(BusinessDirectory.Manifest metadata,File input)throws Exception{try(InputStream in=new FileInputStream(input)){return BusinessDirectory.install(in,new File(root,"candidate-cache"),metadata);}}
 private static long scalar(SQLiteDatabase db,String sql){try(Cursor c=db.rawQuery(sql,null)){assertTrue(c.moveToFirst());return c.getLong(0);}}
 private static String cleaned(Cursor c,int i,String fallback){String value=c.getString(i);return value==null||value.trim().isEmpty()?fallback:value.trim();}
 private static List<Long> queryAll(SQLiteDatabase db,BusinessDirectory.Manifest manifest,String text){
  ArrayList<Long> result=new ArrayList<>();HashSet<Long> unique=new HashSet<>();
  for(int offset=0;;offset+=BusinessDirectory.PAGE_SIZE){
   BusinessDirectory.Page page=BusinessDirectory.query(db,manifest,text,offset);
   assertEquals(BusinessDirectory.Status.AVAILABLE,page.status);assertEquals(offset,page.offset);
   assertTrue(page.entries.size()<=50);if(page.hasMore)assertEquals(50,page.entries.size());
   for(BusinessDirectory.Entry entry:page.entries){assertTrue("duplicate id "+entry.id,unique.add(entry.id));result.add(entry.id);}
   if(!page.hasMore)break;assertTrue("unbounded pagination",offset<2_000_000);
  }
  return result;
 }
 @Test public void exactCandidateManifestInstallsReadOnlyAndPreservesPrivateCanary()throws Exception {
  assertTrue(manifest.recordCount>0);assertEquals("ODbL-1.0",manifest.license);
  File installed=install(manifest,source);assertEquals(sourceHash,hash(installed));
  try(SQLiteDatabase db=SQLiteDatabase.openDatabase(installed.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
   assertEquals(33,RuntimeEnvironment.getApiLevel());assertTrue(db.isReadOnly());assertEquals(1,db.getVersion());assertEquals(manifest.recordCount,scalar(db,"SELECT count(*) FROM businesses"));
   try(Cursor version=db.rawQuery("SELECT sqlite_version()",null)){assertTrue(version.moveToFirst());observations.put("host_sqlite_version",version.getString(0));}
   assertEquals(manifest.recordCount,scalar(db,"SELECT count(*) FROM business_search"));
   assertEquals(0,scalar(db,"SELECT count(*) FROM businesses b LEFT JOIN business_search s ON b.id=s.docid WHERE s.docid IS NULL"));
   try{db.execSQL("DELETE FROM businesses");fail("read-only candidate accepted mutation");}catch(SQLiteException expected){}
  }
  assertEquals(sourceHash,hash(installed));observations.put("installation_readonly_and_canary","PASS");
 }
 @Test public void everyRecordSurvivesActualReaderPagesWithExactNamesAndDialIdentities()throws Exception {
  int count=0,pages=0;HashSet<Long> ids=new HashSet<>();
  try(SQLiteDatabase db=open();Cursor expected=db.rawQuery("SELECT id,name,phone,phone_display,city,category,address,source_url,source_id,source_license,source_updated_at,normalized_phone FROM businesses ORDER BY name COLLATE NOCASE,id",null)){
   for(int offset=0;;offset+=50){
    BusinessDirectory.Page page=BusinessDirectory.query(db,manifest,"",offset);pages++;
    assertEquals(offset,page.offset);assertEquals(Math.min(50,manifest.recordCount-offset),page.entries.size());
    assertEquals(offset+50<manifest.recordCount,page.hasMore);
    for(BusinessDirectory.Entry entry:page.entries){
     assertTrue(expected.moveToNext());assertTrue(ids.add(entry.id));assertEquals(expected.getLong(0),entry.id);
     assertEquals(expected.getString(1),entry.name);assertEquals(expected.getString(11),entry.phone);
     assertEquals(BusinessDirectory.normalizedPhone(expected.getString(2)),entry.phone);
     assertEquals(cleaned(expected,3,expected.getString(2)),entry.phoneDisplay);
     assertEquals(BusinessDirectory.normalizedPhone(entry.phoneDisplay),entry.phone);
     assertEquals(cleaned(expected,4,""),entry.city);assertEquals(cleaned(expected,5,""),entry.category);
     assertEquals(cleaned(expected,6,""),entry.address);assertEquals(expected.getString(7),entry.sourceUrl);
     assertEquals(expected.getString(8),entry.sourceId);assertEquals(cleaned(expected,9,manifest.license),entry.sourceLicense);
     assertEquals(cleaned(expected,10,manifest.updatedAt),entry.sourceUpdatedAt);count++;
    }
    if(!page.hasMore)break;
   }
   assertFalse(expected.moveToNext());assertEquals(manifest.recordCount,count);
  }
  observations.put("full_reader_records",count);observations.put("full_reader_pages",pages);
  observations.put("all_fields_and_dial_identities","PASS");
 }
 @Test public void everyDistinctPhoneSearchKeepsAllSharedSourceIdentities()throws Exception {
  int groups=0,shared=0,queries=0;
  try(SQLiteDatabase db=open();Cursor phones=db.rawQuery("SELECT normalized_phone,min(phone),count(*) FROM businesses GROUP BY normalized_phone ORDER BY normalized_phone",null)){
   while(phones.moveToNext()){
    String national=phones.getString(0),sourcePhone=phones.getString(1);ArrayList<Long> expected=new ArrayList<>();
    try(Cursor rows=db.rawQuery("SELECT id FROM businesses WHERE normalized_phone LIKE ? ORDER BY name COLLATE NOCASE,id",new String[]{national+"%"})){while(rows.moveToNext())expected.add(rows.getLong(0));}
    assertEquals(expected,queryAll(db,manifest,national));queries++;
    assertEquals(expected,queryAll(db,manifest,sourcePhone));queries++;
    if(national.startsWith("0")){
     String international="+972 "+national.substring(1);
     assertEquals(expected,queryAll(db,manifest,international));queries++;
     assertEquals(expected,queryAll(db,manifest,"00972-"+national.substring(1)));queries++;
    }
    if(phones.getInt(2)>1)shared++;groups++;
   }
  }
  assertTrue(groups>0);assertTrue(shared>0);
  observations.put("distinct_phone_groups",groups);observations.put("shared_phone_groups_preserved",shared);
  observations.put("actual_reader_phone_queries",queries);observations.put("phone_queries","PASS");
 }
 @Test public void realUnicodeAndEnglishNamesUseActualFts4WithLiteralPunctuation()throws Exception {
  try(SQLiteDatabase db=open()){
   String hebrew=null,english=null;long hebrewId=0,englishId=0;
   try(Cursor rows=db.rawQuery("SELECT id,name FROM businesses ORDER BY id",null)){
    while(rows.moveToNext()){
     String normalized=Normalizer.normalize(rows.getString(1),Normalizer.Form.NFKD).replaceAll("\\p{M}+","");
     for(String token:normalized.split("[^\\p{L}\\p{N}]+")){
      if(hebrew==null&&token.matches("[א-ת]{3,}")){hebrew=token;hebrewId=rows.getLong(0);}
      if(english==null&&token.matches("[A-Za-z]{3,}")){english=token;englishId=rows.getLong(0);}
     }
     if(hebrew!=null&&english!=null)break;
    }
   }
   assertNotNull(hebrew);assertNotNull(english);
   List<Long> baseline=queryAll(db,manifest,hebrew);assertTrue(baseline.contains(hebrewId));
   String marked=hebrew.substring(0,1)+"\u05B0"+hebrew.substring(1);
   assertEquals(baseline,queryAll(db,manifest,marked));assertEquals(baseline,queryAll(db,manifest,"("+hebrew+")!"));
   List<Long> latin=queryAll(db,manifest,english);assertTrue(latin.contains(englishId));
   assertEquals(latin,queryAll(db,manifest,english.toUpperCase(Locale.ROOT)));
   assertEquals(latin,queryAll(db,manifest,"(\""+english+"\")!"));
   for(String hostile:new String[]{"' OR 1=1 --","%","*","()\""})assertTrue(queryAll(db,manifest,hostile).isEmpty());
   // Exercise a multi-token actual-source name with native implicit intersection.
   String multiple=null;long multipleId=0;
   try(Cursor rows=db.rawQuery("SELECT id,name FROM businesses ORDER BY id",null)){
    while(rows.moveToNext()){
     String name=rows.getString(1),norm=Normalizer.normalize(name,Normalizer.Form.NFKD).replaceAll("\\p{M}+","");
     String[] tokens=norm.replaceAll("[^\\p{L}\\p{N}]+"," ").trim().split(" +");
     if(tokens.length>=2&&tokens[0].length()>=2&&tokens[1].length()>=2){multiple=tokens[0]+" "+tokens[1];multipleId=rows.getLong(0);break;}
    }
   }
   assertNotNull(multiple);assertTrue(queryAll(db,manifest,multiple).contains(multipleId));
   assertFalse(BusinessDirectory.matchExpression(multiple).contains(" AND "));
   observations.put("text_queries","PASS");observations.put("hebrew_query",hebrew);
   observations.put("hebrew_niqqud_query",marked);observations.put("english_query",english);
   observations.put("implicit_intersection_query",multiple);
  }
 }
 @Test public void exactReaderRejectsWrongManifestTypesAndCorruptChecksumWithoutReplacingGoodCopy()throws Exception {
  File installed=install(manifest,source);
  for(String field:new String[]{"record_count","schema_version"}){
   for(Object wrong:new Object[]{Boolean.TRUE,"1",1.5}){
    JSONObject bad=json().put(field,wrong);
    try{modifiedManifest(bad);fail("manifest accepted "+field+"="+wrong);}catch(IOException expected){}
   }
  }
  JSONObject bad=json().put("database_sha256",String.join("",Collections.nCopies(64,"f")));
  try{install(modifiedManifest(bad),source);fail("false checksum accepted");}catch(IOException expected){assertTrue(expected.getMessage().contains("checksum"));}
  assertEquals(sourceHash,hash(installed));
  for(File part:Objects.requireNonNull(new File(root,"candidate-cache").listFiles()))assertFalse(part.getName().endsWith(".part"));
  observations.put("negative_manifest_and_checksum","PASS");
 }
 @Test public void equalDigestCannotHideSchemaCountOrFtsIdentityCorruption()throws Exception {
  File installed=install(manifest,source);int checked=0;
  String[] mutations={"PRAGMA user_version=2","DELETE FROM businesses WHERE id=(SELECT min(id) FROM businesses)",
   "UPDATE metadata SET value='wrong-version' WHERE key='dataset_version'",
   "DELETE FROM business_search WHERE docid=(SELECT min(docid) FROM business_search)",
   "UPDATE business_search SET docid=9223372036854775000 WHERE docid=(SELECT min(docid) FROM business_search)"};
  for(int i=0;i<mutations.length;i++){
   File copy=new File(root,"negative-"+i+".sqlite");Files.copy(source.toPath(),copy.toPath());
   try(SQLiteDatabase db=SQLiteDatabase.openDatabase(copy.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){db.execSQL(mutations[i]);}
   BusinessDirectory.Manifest changed=modifiedManifest(json().put("database_sha256",hash(copy)));
   try{install(changed,copy);fail("corruption accepted: "+mutations[i]);}catch(IOException expected){}
   assertEquals(sourceHash,hash(installed));checked++;
  }
  observations.put("negative_self_consistent_database_cases",checked);observations.put("schema_count_fts_rejection","PASS");
 }
}
