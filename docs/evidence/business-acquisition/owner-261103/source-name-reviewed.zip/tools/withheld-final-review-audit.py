#!/usr/bin/env python3
"""Independent audit of the exact two-tag outside-app name derivative.

No new producer/projector is imported. Existing native-compatible phone/text/FTS
normalizers are disclosed reference contracts. No PBF object reread, Android,
emulator, source-currentness, production or publication approval is established.
"""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import re
import sqlite3
import sys
import unicodedata

REPO = Path('/workspace/D.A.-Caller')
sys.path.insert(0, str(REPO/'scripts/business-directory/research'))
from phone_identity_review import production_packager

PARENT_SHA='4eee8e84a3ccab3f291cb58be1e384a0dc16351612511cfe884e14519af3fd0e'
PARENT_FILES={
 'candidate-businesses.sqlite':PARENT_SHA,
 'candidate-reader-manifest.json':'be9ce29231392c50920fdaaf53a9375a24a810a9b5bf65a3d6bf200f1179ee88',
 'candidate-review-envelope.json':'764add4727a2598ec28277bac0dab10fb4b06039b225111098334d497d8d4439',
 'candidate-decisions.ndjson':'18303b1c9e46f49adddcb6ba3323f64e86ce0c8ec5f691f38c61d34ce72421de',
 'input-binding.json':'b0533ce259fc71ffd0959c05314f479b84cc2b7cf8bb7844d41c0e51dca1450a',
}
REPORT_SHA='e04848419c58d79e9d3e5eeab9c3e778cfa3f223554966f374625d4bd3a299fc'
SELECTED={
 'osm:node:5801536067':('ee14d01f178fbf01f8c69ecf2260d819f4f74eecc2f3dc89914e4b58677b1cf3','دار كنا الضيافة'),
 'osm:node:12543641901':('47ab06491d476194656605194af2ad9b0582d829cd069eaeee632592a9b907d7','R. Gallery Ltd'),
}
COLS=('id','name','phone','phone_display','city','category','address','source_url','source_id','source_license','source_updated_at','normalized_phone')

def require(value,message):
 if not value:raise ValueError(message)

def digest(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def readonly(path):
 return sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)

def keyed_rows(connection,table):
 return {row[0]:tuple(row) for row in connection.execute('SELECT * FROM '+table)}

def fts_rows(connection):
 return {row[0]:tuple(row[1:]) for row in connection.execute('SELECT docid,name,city,category,phone FROM business_search')}

def get_parent(parent):
 dbpath=parent/'candidate-businesses.sqlite'
 report_path=REPO/'docs/evidence/business-acquisition/owner-261103/text-readiness-report.json'
 for name,h in PARENT_FILES.items():require(digest(parent/name)==h,'Immutable parent file differs: '+name)
 require(digest(report_path)==REPORT_SHA,'Exact retained source reread report differs')
 snapshots={Path(p):h for p,h in json.loads((parent/'input-binding.json').read_text()).items()}
 snapshots.update({parent/name:h for name,h in PARENT_FILES.items()})
 snapshots.update({dbpath:PARENT_SHA, report_path:REPORT_SHA})
 for p,h in snapshots.items():require(digest(p)==h,'Bound parent/source input differs: '+str(p))
 report=json.loads(report_path.read_text())
 source_reports={r['original_record']['source_id']:r for r in report['rows']}
 core=production_packager()
 with readonly(dbpath) as db:
  raw=keyed_rows(db,'candidate_raw_records');old_decisions=keyed_rows(db,'candidate_decisions')
  old_business=keyed_rows(db,'businesses');old_fts=fts_rows(db)
 require(len(raw)==len(old_decisions)==2728 and len(old_business)==len(old_fts)==2715,'Parent counts differ')
 added={};selection={}
 for key,record in raw.items():
  source=json.loads(record[3]);sid=source['source_id']
  if sid not in SELECTED:continue
  line_sha,name=SELECTED[sid]
  require(hashlib.sha256(record[3]).hexdigest()==record[4]==line_sha,'Selected raw source-line bytes differ')
  observation=source_reports[sid]
  require(observation['original_record']==source and observation['failed_fields']==['name'],'Source row/name-only failure changed')
  reread=observation['independent_source_node'];tags=reread['source_fields']
  require(reread['source_id']==sid and reread['source_url']==source['source_url']
          and reread['source_updated_at']==source['source_updated_at'],'Source reread identity/time differs')
  require(tags['name']==source['source_names']['name']==name,'Exact primary source name differs')
  require(tags['name:he']==source['name'] and any(unicodedata.category(c)=='Cf' for c in source['name']),
          'Original unsafe preferred Hebrew name lost or changed')
  require(core.bounded_text(name,300)==name and len(name.encode('utf-16-le'))//2<=300,'Selected name needs repair or exceeds Java limit')
  require(source['country_tag'] is None and source['source_country_fields']=={}
          and source['geographic_scope']!='explicit-il','Original missing country/scope changed')
  require(source['extension']=='','Unexpected selected extension')
  canonical=core.normalized_phone(source['phone']);require(bool(canonical),'Selected source dial identity invalid')
  identity=sid+':'+canonical
  stable=int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8],'big')&((1<<63)-1)
  require(stable>0 and stable not in old_business and stable not in added,'Source identity collision')
  values=(stable,name,source['phone'],source['phone'],source['city'],source['category'],source['address'],
          source['source_url'],sid,'ODbL-1.0',source['source_updated_at'],canonical)
  added[stable]=values;selection[key]={'source':source,'line_sha256':line_sha,'values':values,'source_report':observation}
 require(len(added)==len(selection)==2,'Exactly two bound name-only records required')
 return raw,old_decisions,old_business,old_fts,added,selection,snapshots

def validate_table_union(db, raw, decisions, old_business, old_fts, added):
 require(keyed_rows(db,'candidate_raw_records')==raw,'Original source BLOB/history changed')
 require(keyed_rows(db,'candidate_decisions')==decisions,'Original candidate decisions changed')
 require(keyed_rows(db,'businesses')=={**old_business,**added},'Business union is not exact old rows plus two reviewed names')
 core=production_packager()
 new_fts={key:(core.search_text(v[1]),core.search_text(v[4]),core.search_text(v[5]),v[2]) for key,v in added.items()}
 require(fts_rows(db)=={**old_fts,**new_fts},'Old/new FTS fields or identities differ')
 require(tuple(r[1] for r in db.execute('PRAGMA table_info(businesses)'))==COLS,'Reader columns differ')
 require(db.execute('PRAGMA user_version').fetchone()[0]==1,'Reader schema version differs')
 require(db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
         and not db.execute('PRAGMA foreign_key_check').fetchall(),'SQLite integrity/foreign keys failed')

def query_observations(db,added):
 result={}
 for query in ('"دار*" "كنا*"','"Gallery*"','"R*" "Gallery*"'):
  found=list(db.execute('SELECT source_id,name FROM businesses WHERE id IN '
      '(SELECT docid FROM business_search WHERE business_search MATCH ?) ORDER BY name COLLATE NOCASE,id',(query,)))
  expected=SELECTED['osm:node:5801536067'][1] if 'دار' in query else SELECTED['osm:node:12543641901'][1]
  require(any(name==expected for sid,name in found),'Selected source name not searchable: '+query)
  result[query]={'rows':len(found),'selected_exact_name_found':True}
 gathered=[];pages=0
 for offset in range(0,2800,50):
  page=list(db.execute('SELECT id FROM businesses ORDER BY name COLLATE NOCASE,id LIMIT 51 OFFSET ?',(offset,)))
  gathered.extend(row[0] for row in page[:50]);pages+=1
  if len(page)<=50:break
 require(len(gathered)==len(set(gathered))==2717,'Derivative 50+1 pages lost/repeated rows')
 result['all_pages']={'pages':pages,'rows':len(gathered),'lookahead':51}
 return result

def audit(parent,derivative):
 raw,decisions,old_business,old_fts,added,selected,snapshots=get_parent(parent)
 dbpath=derivative/'candidate-businesses.sqlite'
 manifest_path=derivative/'candidate-reader-manifest.json'
 envelope_path=derivative/'candidate-review-envelope.json'
 ledger_path=derivative/'candidate-source-name-selections.ndjson'
 binding_path=derivative/'source-name-input-binding.json'
 manifest=json.loads(manifest_path.read_text());envelope=json.loads(envelope_path.read_text())
 before=digest(dbpath)
 require(manifest['format']=='DA_CALLER_BUSINESSES' and type(manifest['schema_version']) is int
         and manifest['schema_version']==1 and type(manifest['record_count']) is int
         and manifest['record_count']==2717 and manifest['database_sha256']==before,'Actual reader manifest differs')
 require(isinstance(manifest['dataset_version'],str) and re.fullmatch(r'[A-Za-z0-9._-]{1,80}',manifest['dataset_version']),
         'Bounded plain string derivative version required')
 require(dbpath.stat().st_size<=512*1024*1024 and manifest_path.stat().st_size<=65536,'Native size bounds exceeded')
 require(envelope['status']=='CANDIDATE_FOR_REVIEW_NOT_ADMITTED'
         and envelope['profile']=='EXACT_SOURCE_NAME_SELECTION_DERIVATIVE_NOT_ADMITTED'
         and envelope['production_admission'] is False and envelope['publication_approval'] is False
         and envelope['native_integration']=='NOT_TESTED'
         and type(envelope['app_records_added']) is int and envelope['app_records_added']==0,
         'Derivative envelope must remain explicitly non-admitted/non-native')
 builder=REPO/'scripts/business-directory/research/derive_source_name_candidate.py'
 check=REPO/'scripts/business-directory/research/check_source_name_candidate.py'
 policy=REPO/'docs/releases/business-source-name-selection-review.md'
 require(envelope['database_sha256']==before and envelope['database_bytes']==dbpath.stat().st_size
         and envelope['reader_manifest_sha256']==digest(manifest_path)
         and envelope['decision_ledger_sha256']==PARENT_FILES['candidate-decisions.ndjson']
         and envelope['source_name_selection_ledger_sha256']==digest(ledger_path)
         and envelope['parent_database_sha256']==PARENT_SHA
         and envelope['parent_envelope_sha256']==PARENT_FILES['candidate-review-envelope.json']
         and envelope['source_text_report_sha256']==REPORT_SHA
         and envelope['source_name_selection_builder_sha256']==digest(builder)
         and envelope['source_name_selection_check_sha256']==digest(check)
         and envelope['source_name_selection_policy_sha256']==digest(policy),'Derivative source/code/policy binding differs')
 for name in ('candidate-decisions.ndjson','input-binding.json','expanded-research-replay.json'):
  require((derivative/name).read_bytes()==(parent/name).read_bytes(),'Historical bytes changed: '+name)
 for name in ('candidate-reader-manifest.json','candidate-review-envelope.json'):
  require((derivative/('parent-'+name)).read_bytes()==(parent/name).read_bytes(),'Original parent metadata copy changed')
 require(digest(derivative/'bound-source-text-report.json')==REPORT_SHA,'Retained raw source proof changed')
 require((derivative/'source-name-selection-policy-review.md').read_bytes()==policy.read_bytes(),'Retained policy differs')
 require(not any((derivative/name).exists() for name in ('app-assets','business-directory','manifest.json')),
         'Derivative cannot emit production asset layout')
 new_bindings=json.loads(binding_path.read_text())
 resolved_bindings={}
 for path,h in new_bindings.items():
  resolved=Path(path).resolve()
  require(resolved not in resolved_bindings or resolved_bindings[resolved]==h,'Conflicting aliases in input bindings')
  resolved_bindings[resolved]=h
 require(all(resolved_bindings.get(path.resolve())==h for path,h in snapshots.items()),
         'Original parent/source bindings absent or overwritten in derivative snapshot')
 for path,h in new_bindings.items():
  require(digest(Path(path))==h,'Derivative input/source binding changed: '+path)
  if Path(path) in snapshots:require(snapshots[Path(path)]==h,'Original pinned input hash overwritten')
  snapshots[Path(path)]=h
 require(all(path.resolve() in resolved_bindings for path in (builder,check,policy)),'Own code/check/policy absent from bindings')
 events=[json.loads(line) for line in ledger_path.read_text().splitlines()]
 require(len(events)==2 and {e['record_key'] for e in events}==set(selected),'Exactly two source selection events required')
 expected_selection={}
 for event in events:
  key=event['record_key'];item=selected[key];source=item['source'];v=item['values']
  expected_selection[key]=(key,v[0],'WITHHELD_SOURCE_TEXT','name',source['name'],v[1],source['source_id'],
       source['source_url'],source['source_updated_at'],item['line_sha256'],REPORT_SHA,0)
  expected=dict(record_key=key,source_id=source['source_id'],old_decision='WITHHELD_SOURCE_TEXT',old_candidate_business_id=None,
    derivative_decision='SELECTED_EXACT_SOURCE_NAME_FOR_REVIEW_NOT_ADMITTED',new_candidate_business_id=v[0],
    selected_source_tag='name',selected_source_value=v[1],original_preferred_tag='name:he',original_preferred_value=source['name'],
    original_line_sha256=item['line_sha256'],source_url=source['source_url'],source_updated_at=source['source_updated_at'],
    source_version=source.get('source_version'),source_version_absent_in_raw='source_version' not in source,
    source_phone=source['phone'],original_phone=source['original_phone'],extension=source['extension'],original_country=None,
    original_country_fields={},original_scope=source['geographic_scope'],source_text_report_sha256=REPORT_SHA,
    source_pbf_sha256='62c6ff161b738588454719f0fd1c4971c9b46535f4ab04313e7bbe1dd582afdf',source_mutations=0,
    app_admitted=False,production_admission=False,publication_approval=False)
  require(event==expected,'Selection event changed raw source/history/value/provenance')
 with readonly(dbpath) as db:
  validate_table_union(db,raw,decisions,old_business,old_fts,added)
  require(keyed_rows(db,'candidate_source_name_selections')==expected_selection,'Selection SQL/provenance differs')
  require(db.execute("SELECT value FROM metadata WHERE key='dataset_version'").fetchone()[0]==manifest['dataset_version'],
          'Plain-string metadata version differs')
  effective=[v[1] for k,v in decisions.items() if v[2] is None and k not in selected]
  require(collections.Counter(effective)=={'WITHHELD_PHONE_FORMAT_REVIEW':10,'WITHHELD_SOURCE_TEXT':1},'Remaining withholding changed')
  require(db.execute('SELECT sum(app_admitted) FROM candidate_decisions').fetchone()[0]==0
          and db.execute('SELECT sum(app_admitted) FROM candidate_source_name_selections').fetchone()[0]==0,'Admission side effect')
  actual_union={**old_business,**added}
  ids={v[2] for v in decisions.values() if v[2] is not None}|{v[0] for v in added.values()}
  require(ids==set(actual_union),'Effective projection union has orphan/missing IDs')
  queries=query_observations(db,added)
  negative=[]
  for label,sql,args in (
   ('old-business-change','UPDATE businesses SET name=? WHERE id=?',('changed',next(iter(old_business)))),
   ('selected-business-change','UPDATE businesses SET name=? WHERE id=?',('changed',next(iter(added)))),
   ('selected-fts-missing','DELETE FROM business_search WHERE docid=?',(next(iter(added)),)),
   ('historical-decision-change','UPDATE candidate_decisions SET decision=? WHERE record_key=?',('WITHHELD_EXTENSION',next(iter(selected)))),
  ):
   memory=sqlite3.connect(':memory:');db.backup(memory);memory.execute(sql,args)
   try:validate_table_union(memory,raw,decisions,old_business,old_fts,added)
   except ValueError:negative.append(label)
   else:raise ValueError('Corruption was not rejected: '+label)
   finally:memory.close()
  for label,sql in (
   ('selected-app-admission-check',"UPDATE candidate_source_name_selections SET app_admitted=1"),
   ('selected-tag-check',"UPDATE candidate_source_name_selections SET selected_tag='name:he'"),
  ):
   memory=sqlite3.connect(':memory:');db.backup(memory)
   try:memory.execute(sql)
   except sqlite3.IntegrityError:negative.append(label)
   else:raise ValueError('CHECK corruption was not rejected: '+label)
   finally:memory.close()
  measured=dict(raw_source_rows=len(raw),historical_decisions=len(decisions),candidate_rows=len(actual_union),
      unchanged_parent_rows=len(old_business),source_name_selections=len(added),source_objects=len({v[8] for v in actual_union.values()}),
      normalized_phones=len({v[11] for v in actual_union.values()}),effective_source_text_withheld=1,effective_phone_format_withheld=10)
 require(envelope['counts']['candidate_rows']==measured['candidate_rows']
         and envelope['counts']['candidate_source_objects']==measured['source_objects']
         and envelope['counts']['candidate_distinct_normalized_phones']==measured['normalized_phones'], 'Measured envelope counts differ')
 rejection=collections.Counter();core=production_packager()
 for r in raw.values():
  try:core.record_values(json.loads(r[3]))
  except ValueError as e:rejection[str(e)]+=1
  else:raise ValueError('Original source unexpectedly production admitted')
 for path,h in snapshots.items():require(digest(path)==h,'Bound source/code changed during independent audit')
 require(digest(dbpath)==before,'Derivative changed after readonly audit')
 return dict(status='PASS_EXACT_SOURCE_NAME_DERIVATIVE_SQL_AND_SOURCE_AUDIT_ONLY',observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
   parent_database_sha256=PARENT_SHA,candidate_database_sha256=before,candidate_database_bytes=dbpath.stat().st_size,
   candidate_manifest_sha256=digest(manifest_path),candidate_envelope_sha256=digest(envelope_path),
   source_name_event_ledger_sha256=digest(ledger_path),source_text_report_sha256=REPORT_SHA,
   reviewed_builder_sha256=digest(builder),reviewed_policy_sha256=digest(policy),audit_script_sha256=digest(Path(__file__)),
   measured_counts=measured,actual_sql_queries=queries,negative_memory_checks=negative,original_strict_production_rejections=dict(rejection),
   all_original_49_parent_bindings_rechecked=True,parent_raw_and_decision_history_unchanged=True,old_2715_rows_and_fts_unchanged=True,
   original_pbf_objects_reread=False,app_records_added=0,production_admission=False,native_integration='NOT_TESTED',publication_approval=False,
   limits=['The new derivative producer/projector was not imported; every row and selection event was independently reconstructed.',
           'Existing native-compatible phone/text/FTS normalizers are shared disclosed references.',
           'These are retained-source and desktop SQLite checks, not new Android/emulator/Telecom/UI/native integration tests.',
           'No live business/phone ownership/currentness, legal-country or nationwide coverage guarantee.'])

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser(description=__doc__)
 for arg in ('parent','derivative','output'):p.add_argument(arg,type=Path)
 args=p.parse_args();require(not args.output.exists(),'Audit output exists; select a new path')
 result=audit(args.parent,args.derivative)
 with args.output.open('x') as stream:json.dump(result,stream,ensure_ascii=True,indent=2);stream.write('\n')
 print(json.dumps({k:result[k] for k in ('status','candidate_database_sha256','measured_counts','app_records_added')}))
