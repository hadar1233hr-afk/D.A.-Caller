#!/usr/bin/env python3
"""Bounded actual-host-reader proof; no APK or production admission claims."""
from pathlib import Path
import hashlib,json,subprocess,sys,datetime,xml.etree.ElementTree as ET
base=Path('/workspace/work/business-geometry-host-20261112')
repo=Path('/workspace/D.A.-Caller')
package=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve()
assert output.is_relative_to(base), 'Keep evidence in assigned private directory'
output.mkdir(parents=True,exist_ok=False)
database=package/'app-assets/business-directory/israel-businesses.sqlite'
manifest=package/'app-assets/business-directory/manifest.json'
reader=repo/'app/src/main/java/com/dacaller/app/BusinessDirectory.java'
policy=repo/'docs/business/source-geometry-admission-261103.md'
package_report=package/'verification-report.json'
assert policy.is_file() and package_report.is_file()
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(reader)=='5d8c3d01e4aab6f5dd198b4c2fe588e301c7298003192c21ec97332e279efa52'
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in (database,manifest,reader,policy,package_report,package/'redistribution/coverage.json',base/'init.gradle',base/'src/com/dacaller/app/VerifiedGeometryReaderHostContractTest.java',base/'run-host.sh',base/'run-host.py')}
metadata=json.loads(manifest.read_text());assert metadata['database_sha256']==sha(database)
producer=json.loads(package_report.read_text());assert producer['native_reader_sha256']==sha(reader)
assert producer['database_sha256']==sha(database) and producer['policy_sha256']==sha(policy)
assert sha(policy)=='c421cf24a6442f31b991037a45883234b8570e2ad82dae6cb8f673d2523e4d2c'
assert producer['counts']['projected_rows']==metadata['record_count']
report={'environment':'HOST_ROBOLECTRIC_API33_NATIVE_SQLITE','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':inputs,'package':str(package),'publication_approval':False,'android_emulator':False,'telecom_tested':False,'physical_device_tested':False,'upgrade_tested':False,'app_records_added_by_this_host_check':0,'synthetic_private_canary_only':True}
(output/'input-binding.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
command=['gradle','--offline','--no-daemon','-I',str(base/'init.gradle'),'-Dcandidate.database='+str(database),'-Dcandidate.manifest='+str(manifest),'-Dcandidate.sha256='+sha(database),'-Dcandidate.manifest.sha256='+sha(manifest),'-Dcandidate.reader='+str(reader),'-Dcandidate.reader.sha256='+sha(reader),'-Dcandidate.output='+str(output),':app:testDebugUnitTest','--tests','com.dacaller.app.VerifiedGeometryReaderHostContractTest','--console=plain']
(output/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (output/'host-run.log').open('w') as stream:
    result=subprocess.run(command,cwd=repo,stdout=stream,stderr=subprocess.STDOUT,check=False)
report['process_exit_code']=result.returncode;report['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
report['inputs_unchanged']=all(sha(p)==v['sha256'] for p,v in inputs.items())
cases=[];failures=[]
for path in sorted((output/'junit').glob('TEST-*.xml')):
    root=ET.parse(path).getroot()
    for case in root.iter('testcase'):
        identity=case.get('classname')+'.'+case.get('name');cases.append(identity)
        for flag in ('failure','error','skipped'):
            if case.find(flag) is not None:failures.append({'case':identity,'flag':flag,'text':case.find(flag).get('message')})
report['unique_test_methods']=len(set(cases));report['junit_case_occurrences']=len(cases);report['failures_errors_skips']=failures
report['status']='PASS' if result.returncode==0 and report['inputs_unchanged'] and len(cases)==len(set(cases))==9 and not failures else 'FAIL'
(output/'host-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'cases':report['unique_test_methods'],'failures_errors_skips':failures,'output':str(output)},ensure_ascii=False))
sys.exit(0 if report['status']=='PASS' else 1)
