#!/usr/bin/env bash
set -eu
if [ "$#" -ne 2 ]; then
  echo 'usage: run-host.sh CLEAN_PACKAGE_DIRECTORY NEW_EVIDENCE_OUTPUT_DIRECTORY' >&2
  exit 2
fi
source /workspace/toolchains/activate.sh
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Duser.home=/workspace/D.A.-Caller/work/robolectric-home"
python /workspace/work/business-geometry-host-20261112/run-host.py "$1" "$2"
